import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
// Importa o cliente Supabase (e, opcionalmente, o cliente admin)
import { supabase, supabaseAdmin } from "./database/database.js";
import { errorHandler, notFound } from "./middleware/errorHandler.js";

// Importar rotas adaptadas para o contexto da Clínica Veterinária
// ATENÇÃO: Estes arquivos de rota precisarão ser criados/atualizados
// para lidar com as tabelas e lógica da Clínica Veterinária usando o Supabase.
import usuariosRoutes from "./routes/usuarios.js"; // Nova rota para usuários
import clientesRoutes from "./routes/clientes.js";
import animaisRoutes from "./routes/animais.js"; // Antigo 'veiculosRoutes'
import prontuariosRoutes from "./routes/prontuarios.js"; // Nova rota para prontuários (pode englobar 'servicos')
import prescricoesRoutes from "./routes/prescricoes.js"; // Nova rota para prescrições
import vacinasRoutes from "./routes/vacinas.js"; // Nova rota para vacinas
import anexosProntuarioRoutes from "./routes/anexosProntuario.js"; // Nova rota para anexos de prontuário
import agendamentosRoutes from "./routes/agendamentos.js"; // Nova rota para agendamentos
import produtosRoutes from "./routes/produtos.js"; // Antigo 'estoqueRoutes'
import lotesProdutoRoutes from "./routes/lotesProduto.js"; // Nova rota para lotes de produto
import movimentacaoEstoqueRoutes from "./routes/movimentacaoEstoque.js"; // Nova rota para movimentação de estoque
import faturasRoutes from "./routes/faturas.js";
import itensFaturaRoutes from "./routes/itensFatura.js"; // Nova rota para itens de fatura
import pagamentosRoutes from "./routes/pagamentos.js";
import atendimentoFaturaRoutes from "./routes/atendimentoFatura.js"; // Nova rota para atendimento-fatura

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware de segurança
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // máximo 100 requests por IP por janela de tempo
  message: {
    error: "Muitas requisições",
    message: "Tente novamente em alguns minutos",
  },
});
app.use(limiter);

// CORS
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "*", // Define a origem permitida para o frontend
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// Parse JSON
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Não é mais necessário conectar ao banco de dados explicitamente aqui com Supabase
// A conexão é gerenciada pelo cliente Supabase importado.

// Rota de health check
app.get("/health", async (req, res) => {
  // Um health check mais robusto para Supabase pode tentar uma query simples
  try {
    const { data, error } = await supabase.from("clientes").select("id_cliente").limit(1);

    if (error) {
      console.error("Erro no health check ao Supabase:", error.message);
      return res.status(500).json({
        status: "ERRO",
        message: "Falha na conexão com Supabase",
        details: error.message,
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
      });
    }

    res.json({
      status: "OK",
      message: "Conectado ao Supabase com sucesso!",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  } catch (e) {
    console.error("Erro inesperado no health check:", e.message);
    res.status(500).json({
      status: "ERRO",
      message: "Erro inesperado no health check",
      details: e.message,
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  }
});

// Rota principal (informações da API)
app.get("/", (req, res) => {
  res.json({
    message: "API da Clínica Veterinária Bem Estar Animal",
    version: "1.0.0",
    endpoints: {
      usuarios: "/api/usuarios",
      clientes: "/api/clientes",
      animais: "/api/animais",
      prontuarios: "/api/prontuarios",
      prescricoes: "/api/prescricoes",
      vacinas: "/api/vacinas",
      anexosProntuario: "/api/anexos-prontuario",
      agendamentos: "/api/agendamentos",
      produtos: "/api/produtos",
      lotesProduto: "/api/lotes-produto",
      movimentacaoEstoque: "/api/movimentacao-estoque",
      faturas: "/api/faturas",
      itensFatura: "/api/itens-fatura",
      pagamentos: "/api/pagamentos",
      atendimentoFatura: "/api/atendimento-fatura",
      health: "/health",
    },
  });
});

// Rotas da API (usando os novos nomes e caminhos)
app.use("/api/usuarios", usuariosRoutes);
app.use("/api/clientes", clientesRoutes);
app.use("/api/animais", animaisRoutes);
app.use("/api/prontuarios", prontuariosRoutes);
app.use("/api/prescricoes", prescricoesRoutes);
app.use("/api/vacinas", vacinasRoutes);
app.use("/api/anexos-prontuario", anexosProntuarioRoutes); // Exemplo de rota com traço
app.use("/api/agendamentos", agendamentosRoutes);
app.use("/api/produtos", produtosRoutes);
app.use("/api/lotes-produto", lotesProdutoRoutes);
app.use("/api/movimentacao-estoque", movimentacaoEstoqueRoutes);
app.use("/api/faturas", faturasRoutes);
app.use("/api/itens-fatura", itensFaturaRoutes);
app.use("/api/pagamentos", pagamentosRoutes);
app.use("/api/atendimento-fatura", atendimentoFaturaRoutes);

// Middleware de erro 404
app.use(notFound);

// Middleware de tratamento de erros
app.use(errorHandler);

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor da Clínica Veterinária rodando na porta ${PORT}`);
  console.log(`✅ Cliente Supabase inicializado e pronto para uso.`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`📚 API Base: http://localhost:${PORT}/`);
});

// Graceful shutdown (não há database.close() explícito para Supabase)
process.on("SIGINT", async () => {
  console.log("\n🛑 Encerrando servidor...");
  // Não há necessidade de fechar a conexão com o banco de dados Supabase explicitamente aqui.
  // O cliente Supabase gerencia suas próprias conexões.
  process.exit(0);
});

process.on("SIGTERM", async () => {
  console.log("\n🛑 Encerrando servidor...");
  // Não há necessidade de fechar a conexão com o banco de dados Supabase explicitamente aqui.
  process.exit(0);
});

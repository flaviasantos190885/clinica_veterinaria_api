/*
  # Clínica Veterinária Bem Estar Animal - Schema Database

  1. Tabelas de Usuários e Autenticação
    - `usuarios` - Dados dos usuários do sistema (Veterinários, Recepcionistas, Gestores)
  
  2. Tabelas de Clientes e Animais
    - `clientes` - Dados dos tutores dos animais
    - `animais` - Dados dos animais, vinculados aos tutores
  
  3. Tabelas de Atendimento Médico
    - `prontuarios` - Histórico médico dos animais
    - `prescricoes` - Prescrições médicas
    - `vacinas` - Controle de vacinas
    - `anexos_prontuario` - Anexos dos prontuários
    
  4. Tabelas de Agendamento
    - `agendamentos` - Controle de agendamentos
    
  5. Tabelas de Estoque e Produtos
    - `produtos` - Produtos disponíveis
    - `lotes_produto` - Controle de lotes
    - `movimentacao_estoque` - Histórico de movimentações
    
  6. Tabelas Financeiras
    - `faturas` - Contas a receber
    - `itens_fatura` - Itens detalhados das faturas
    - `pagamentos` - Pagamentos recebidos
    - `atendimento_fatura` - Relacionamento atendimento/fatura

  7. Segurança
    - Habilitado RLS em todas as tabelas
    - Políticas de acesso baseadas em perfil de usuário
*/

-- Criação da tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(100) NOT NULL,
    email varchar(100) UNIQUE NOT NULL,
    senha_hash varchar(255) NOT NULL,
    perfil varchar(50) NOT NULL CHECK (perfil IN ('Veterinário', 'Recepcionista', 'Gestor')),
    ativo boolean DEFAULT true,
    data_cadastro timestamptz DEFAULT now(),
    data_atualizacao timestamptz DEFAULT now()
);

-- Criação da tabela de Clientes (Tutores)
CREATE TABLE IF NOT EXISTS clientes (
    id_cliente uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(100) NOT NULL,
    cpf varchar(14) UNIQUE NOT NULL,
    telefone varchar(20),
    email varchar(100),
    endereco varchar(255),
    data_cadastro timestamptz DEFAULT now(),
    data_atualizacao timestamptz DEFAULT now(),
    ativo boolean DEFAULT true
);

-- Criação da tabela de Animais
CREATE TABLE IF NOT EXISTS animais (
    id_animal uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_cliente uuid NOT NULL REFERENCES clientes(id_cliente),
    nome varchar(100) NOT NULL,
    especie varchar(50) NOT NULL,
    raca varchar(50),
    data_nascimento date,
    sexo char(1) CHECK (sexo IN ('M', 'F')),
    peso decimal(6,2),
    observacoes text,
    data_cadastro timestamptz DEFAULT now(),
    data_atualizacao timestamptz DEFAULT now()
);

-- Criação da tabela de Prontuarios
CREATE TABLE IF NOT EXISTS prontuarios (
    id_prontuario uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_animal uuid NOT NULL REFERENCES animais(id_animal),
    data_atendimento timestamptz DEFAULT now(),
    id_veterinario uuid NOT NULL REFERENCES usuarios(id_usuario),
    tipo_atendimento varchar(50),
    anamnese text,
    diagnostico text,
    procedimentos_realizados text,
    observacoes text
);

-- Tabela para armazenar as prescrições
CREATE TABLE IF NOT EXISTS prescricoes (
    id_prescricao uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_prontuario uuid NOT NULL REFERENCES prontuarios(id_prontuario),
    medicamento varchar(100) NOT NULL,
    dosagem varchar(50),
    frequencia varchar(50),
    duracao varchar(50),
    observacoes text,
    data_prescricao timestamptz DEFAULT now()
);

-- Tabela para gerenciar vacinas registradas no prontuário
CREATE TABLE IF NOT EXISTS vacinas (
    id_vacina uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_prontuario uuid NOT NULL REFERENCES prontuarios(id_prontuario),
    nome_vacina varchar(100) NOT NULL,
    data_aplicacao date NOT NULL,
    data_proxima_dose date,
    lote varchar(50)
);

-- Tabela para gerenciar anexos (imagens, documentos) aos prontuários
CREATE TABLE IF NOT EXISTS anexos_prontuario (
    id_anexo uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_prontuario uuid NOT NULL REFERENCES prontuarios(id_prontuario),
    nome_arquivo varchar(255) NOT NULL,
    caminho_arquivo varchar(255) NOT NULL,
    tipo_arquivo varchar(50),
    data_upload timestamptz DEFAULT now()
);

-- Criação da tabela de Agendamentos
CREATE TABLE IF NOT EXISTS agendamentos (
    id_agendamento uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_animal uuid NOT NULL REFERENCES animais(id_animal),
    id_cliente uuid NOT NULL REFERENCES clientes(id_cliente),
    id_veterinario uuid NOT NULL REFERENCES usuarios(id_usuario),
    data_hora_inicio timestamptz NOT NULL,
    data_hora_fim timestamptz NOT NULL,
    tipo_agendamento varchar(50) NOT NULL,
    status_agendamento varchar(50) NOT NULL DEFAULT 'Agendado' CHECK (status_agendamento IN ('Agendado', 'Confirmado', 'Cancelado', 'Realizado')),
    observacoes text,
    data_cadastro timestamptz DEFAULT now(),
    data_atualizacao timestamptz DEFAULT now()
);

-- Criação da tabela de Produtos
CREATE TABLE IF NOT EXISTS produtos (
    id_produto uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(100) NOT NULL,
    descricao text,
    preco_venda decimal(10,2) NOT NULL,
    unidade_medida varchar(20),
    estoque_atual integer NOT NULL DEFAULT 0,
    estoque_minimo integer NOT NULL DEFAULT 0,
    data_cadastro timestamptz DEFAULT now(),
    data_atualizacao timestamptz DEFAULT now(),
    ativo boolean DEFAULT true
);

-- Tabela para controle de lotes de produtos
CREATE TABLE IF NOT EXISTS lotes_produto (
    id_lote uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_produto uuid NOT NULL REFERENCES produtos(id_produto),
    numero_lote varchar(50) NOT NULL,
    data_validade date NOT NULL,
    quantidade_inicial integer NOT NULL,
    quantidade_disponivel integer NOT NULL,
    data_entrada timestamptz DEFAULT now()
);

-- Criação da tabela de MovimentacaoEstoque
CREATE TABLE IF NOT EXISTS movimentacao_estoque (
    id_movimentacao uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_produto uuid NOT NULL REFERENCES produtos(id_produto),
    id_lote uuid REFERENCES lotes_produto(id_lote),
    tipo_movimentacao varchar(20) NOT NULL CHECK (tipo_movimentacao IN ('Entrada', 'Saida_Venda', 'Saida_Uso', 'Ajuste_Positivo', 'Ajuste_Negativo')),
    quantidade integer NOT NULL,
    data_movimentacao timestamptz DEFAULT now(),
    id_usuario_responsavel uuid REFERENCES usuarios(id_usuario),
    observacoes text
);

-- Criação da tabela de Faturas
CREATE TABLE IF NOT EXISTS faturas (
    id_fatura uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_atendimento uuid REFERENCES prontuarios(id_prontuario),
    id_cliente uuid NOT NULL REFERENCES clientes(id_cliente),
    data_emissao timestamptz DEFAULT now(),
    data_vencimento date,
    valor_total decimal(10,2) NOT NULL,
    status_fatura varchar(50) NOT NULL DEFAULT 'Pendente' CHECK (status_fatura IN ('Pendente', 'Paga', 'Parcialmente_Paga', 'Cancelada')),
    observacoes text
);

-- Tabela para detalhar os itens de cada fatura
CREATE TABLE IF NOT EXISTS itens_fatura (
    id_item_fatura uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_fatura uuid NOT NULL REFERENCES faturas(id_fatura),
    id_produto uuid REFERENCES produtos(id_produto),
    descricao_servico varchar(255),
    quantidade integer NOT NULL DEFAULT 1,
    valor_unitario decimal(10,2) NOT NULL,
    valor_total_item decimal(10,2) NOT NULL
);

-- Tabela para registrar os pagamentos recebidos
CREATE TABLE IF NOT EXISTS pagamentos (
    id_pagamento uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_fatura uuid NOT NULL REFERENCES faturas(id_fatura),
    data_pagamento timestamptz DEFAULT now(),
    valor_pago decimal(10,2) NOT NULL,
    forma_pagamento varchar(50) NOT NULL,
    observacoes text
);

-- Tabela para registrar o mapeamento entre um atendimento e sua fatura
CREATE TABLE IF NOT EXISTS atendimento_fatura (
    id_atendimento_fatura uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    id_prontuario uuid NOT NULL REFERENCES prontuarios(id_prontuario),
    id_fatura uuid NOT NULL REFERENCES faturas(id_fatura),
    UNIQUE (id_prontuario, id_fatura)
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE animais ENABLE ROW LEVEL SECURITY;
ALTER TABLE prontuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescricoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE vacinas ENABLE ROW LEVEL SECURITY;
ALTER TABLE anexos_prontuario ENABLE ROW LEVEL SECURITY;
ALTER TABLE agendamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE lotes_produto ENABLE ROW LEVEL SECURITY;
ALTER TABLE movimentacao_estoque ENABLE ROW LEVEL SECURITY;
ALTER TABLE faturas ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_fatura ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE atendimento_fatura ENABLE ROW LEVEL SECURITY;

-- Políticas de segurança básicas (usuários autenticados podem acessar dados)
CREATE POLICY "Authenticated users can manage usuarios" ON usuarios FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage clientes" ON clientes FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage animais" ON animais FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage prontuarios" ON prontuarios FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage prescricoes" ON prescricoes FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage vacinas" ON vacinas FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage anexos_prontuario" ON anexos_prontuario FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage agendamentos" ON agendamentos FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage produtos" ON produtos FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage lotes_produto" ON lotes_produto FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage movimentacao_estoque" ON movimentacao_estoque FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage faturas" ON faturas FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage itens_fatura" ON itens_fatura FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage pagamentos" ON pagamentos FOR ALL TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage atendimento_fatura" ON atendimento_fatura FOR ALL TO authenticated USING (true);

-- Indexes para melhorar performance
CREATE INDEX idx_clientes_cpf ON clientes(cpf);
CREATE INDEX idx_animais_cliente ON animais(id_cliente);
CREATE INDEX idx_prontuarios_animal ON prontuarios(id_animal);
CREATE INDEX idx_agendamentos_data ON agendamentos(data_hora_inicio);
CREATE INDEX idx_faturas_cliente ON faturas(id_cliente);
CREATE INDEX idx_faturas_status ON faturas(status_fatura);
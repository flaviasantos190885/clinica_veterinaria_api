import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";

dotenv.config(); // Carrega as variáveis de ambiente do arquivo .env

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY; // Opcional, para operações de backend que ignoram RLS

// Verificação básica das variáveis de ambiente
if (!supabaseUrl || !supabaseAnonKey) {
  console.error("ERRO: As variáveis de ambiente SUPABASE_URL e/ou SUPABASE_ANON_KEY não estão definidas no arquivo .env.");
  console.error("Por favor, verifique se seu arquivo .env contém:");
  console.error("SUPABASE_URL=YOUR_SUPABASE_PROJECT_URL");
  console.error("SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_PUBLIC_KEY");
  // Você pode decidir encerrar o processo se as credenciais essenciais não existirem
  process.exit(1);
}

// Cliente Supabase para uso geral (respeita RLS, ideal para rotas que agem em nome do usuário)
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Cliente Supabase com Service Role Key (ignora RLS, ideal para operações de admin/backend)
// Use com cautela e apenas em contextos seguros (ex: dentro de funções do servidor)
const supabaseAdmin = supabaseServiceRoleKey ? createClient(supabaseUrl, supabaseServiceRoleKey) : null;

console.log("Cliente Supabase inicializado para a Clínica Veterinária.");

// Exporta ambos os clientes como named exports
export { supabase, supabaseAdmin };

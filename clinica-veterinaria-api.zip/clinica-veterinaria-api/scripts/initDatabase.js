import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import database from "../database/database.js"; // Certifique-se de que 'database.js' lida com a conexão e execução de queries.

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ajuste o caminho se o seu arquivo de schema.sql não estiver exatamente aqui
const schemaPath = path.join(__dirname, "..", "database", "schema.sql");

async function initDatabase() {
  try {
    await database.connect();

    // Ler o arquivo SQL
    const schema = fs.readFileSync(schemaPath, "utf8");

    // Dividir o schema em comandos individuais
    const commands = schema
      .split(";")
      .map((cmd) => cmd.trim())
      .filter((cmd) => cmd.length > 0 && !cmd.startsWith("--"));

    // Executar cada comando
    for (const command of commands) {
      if (command.trim()) {
        await database.run(command);
        console.log("Comando executado:", command.substring(0, 50) + "...");
      }
    }

    console.log("Banco de dados inicializado com sucesso!");

    // Inserir alguns dados de exemplo com base no novo esquema
    await insertSampleData();
  } catch (error) {
    console.error("Erro ao inicializar banco de dados:", error);
  } finally {
    await database.close();
  }
}

async function insertSampleData() {
  try {
    // --- Inserção de Usuários de Exemplo ---
    // Você precisará de usuários para referenciar em prontuários e agendamentos
    console.log("Inserindo usuários de exemplo...");
    const user1 = await database.run(`
            INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES
            ('Dr. João Veterinário', 'joao.vet@email.com', 'hash_da_senha_123', 'Veterinário')
            RETURNING id_usuario;
        `);
    const userId1 = user1[0].id_usuario; // Supondo que database.run retorna os resultados

    const user2 = await database.run(`
            INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES
            ('Ana Recepcionista', 'ana.rec@email.com', 'hash_da_senha_456', 'Recepcionista')
            RETURNING id_usuario;
        `);
    const userId2 = user2[0].id_usuario;

    // --- Inserção de Clientes de Exemplo ---
    console.log("Inserindo clientes de exemplo...");
    const client1 = await database.run(`
            INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES
            ('Carlos Oliveira', '111.222.333-44', '(21) 98765-4321', 'carlos.oliver@email.com', 'Rua Alfa, 100')
            RETURNING id_cliente;
        `);
    const clientId1 = client1[0].id_cliente;

    const client2 = await database.run(`
            INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES
            ('Mariana Souza', '555.666.777-88', '(11) 99887-6655', 'mariana.souza@email.com', 'Avenida Beta, 200')
            RETURNING id_cliente;
        `);
    const clientId2 = client2[0].id_cliente;

    // --- Inserção de Animais de Exemplo ---
    console.log("Inserindo animais de exemplo...");
    const animal1 = await database.run(`
            INSERT INTO animais (id_cliente, nome, especie, raca, data_nascimento, sexo, peso) VALUES
            ('${clientId1}', 'Rex', 'Canino', 'Labrador', '2020-03-15', 'M', 30.5)
            RETURNING id_animal;
        `);
    const animalId1 = animal1[0].id_animal;

    const animal2 = await database.run(`
            INSERT INTO animais (id_cliente, nome, especie, raca, data_nascimento, sexo, peso) VALUES
            ('${clientId2}', 'Miau', 'Felino', 'Siamês', '2021-06-01', 'F', 4.2)
            RETURNING id_animal;
        `);
    const animalId2 = animal2[0].id_animal;

    // --- Inserção de Prontuários de Exemplo ---
    console.log("Inserindo prontuários de exemplo...");
    const prontuario1 = await database.run(`
            INSERT INTO prontuarios (id_animal, data_atendimento, id_veterinario, tipo_atendimento, anamnese, diagnostico, procedimentos_realizados) VALUES
            ('${animalId1}', NOW(), '${userId1}', 'Consulta Geral', 'Animal apático, sem apetite.', 'Gastroenterite leve', 'Hidratação e medicação oral.')
            RETURNING id_prontuario;
        `);
    const prontuarioId1 = prontuario1[0].id_prontuario;

    // --- Inserção de Prescrições de Exemplo ---
    console.log("Inserindo prescrições de exemplo...");
    await database.run(`
            INSERT INTO prescricoes (id_prontuario, medicamento, dosagem, frequencia, duracao) VALUES
            ('${prontuarioId1}', 'Amoxicilina', '250mg', '12/12h', '7 dias');
        `);

    // --- Inserção de Vacinas de Exemplo ---
    console.log("Inserindo vacinas de exemplo...");
    await database.run(`
            INSERT INTO vacinas (id_prontuario, nome_vacina, data_aplicacao, data_proxima_dose, lote) VALUES
            ('${prontuarioId1}', 'V8', '2024-05-20', '2025-05-20', 'LOTEABC123');
        `);

    // --- Inserção de Produtos de Exemplo (Antigo Estoque) ---
    console.log("Inserindo produtos de exemplo...");
    const produto1 = await database.run(`
            INSERT INTO produtos (nome, descricao, preco_venda, unidade_medida, estoque_atual, estoque_minimo) VALUES
            ('Ração Premium Cães Adultos', 'Ração seca para cães adultos de raças médias', 85.00, 'Kg', 100, 20)
            RETURNING id_produto;
        `);
    const produtoId1 = produto1[0].id_produto;

    const produto2 = await database.run(`
            INSERT INTO produtos (nome, descricao, preco_venda, unidade_medida, estoque_atual, estoque_minimo) VALUES
            ('Shampoo Dermatológico Gatos', 'Shampoo hipoalergênico para gatos', 45.00, 'Unidade', 50, 10)
            RETURNING id_produto;
        `);
    const produtoId2 = produto2[0].id_produto;

    // --- Inserção de Agendamentos de Exemplo ---
    console.log("Inserindo agendamentos de exemplo...");
    await database.run(`
            INSERT INTO agendamentos (id_animal, id_cliente, id_veterinario, data_hora_inicio, data_hora_fim, tipo_agendamento, status_agendamento) VALUES
            ('${animalId1}', '${clientId1}', '${userId1}', NOW() + INTERVAL '1 day', NOW() + INTERVAL '1 day 30 minutes', 'Consulta de Retorno', 'Agendado');
        `);

    console.log("Dados de exemplo inseridos com sucesso!");
  } catch (error) {
    console.error("Erro ao inserir dados de exemplo:", error);
    // Em caso de erro na inserção, é bom imprimir o comando que falhou
    console.error("Comando SQL com erro:", error.detail || error.message);
  }
}

initDatabase();

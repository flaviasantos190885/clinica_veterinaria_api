API da Clínica Veterinária Bem Estar Animal
API REST completa para sistema de gestão da Clínica Veterinária Bem Estar Animal, desenvolvida com Node.js, Express e Supabase (PostgreSQL).

🚀 Funcionalidades
Gestão de Usuários: CRUD completo para funcionários (Veterinários, Recepcionistas, Gestores)

Gestão de Clientes (Tutores): CRUD completo para tutores de animais

Gestão de Animais: Controle de animais vinculados aos seus tutores

Atendimento Médico:

Prontuários: Histórico médico detalhado dos animais

Prescrições: Registro de medicamentos e tratamentos

Vacinas: Controle de vacinação e próximas doses

Anexos de Prontuário: Gerenciamento de documentos e imagens clínicas

Agendamento: Sistema completo para marcação de consultas e procedimentos

Controle de Estoque:

Produtos: Gerenciamento de itens para venda e uso interno

Lotes de Produto: Rastreamento de lotes e validades

Movimentação de Estoque: Histórico de entradas e saídas de produtos

Faturamento e Financeiro:

Faturas: Geração e controle de contas a receber

Itens de Fatura: Detalhes dos produtos e serviços faturados

Pagamentos: Controle de pagamentos recebidos e status de faturas

Atendimento Fatura: Relação entre atendimentos e suas faturas

📋 Pré-requisitos
Node.js 18+

npm ou yarn

Um projeto Supabase configurado com o esquema de banco de dados da Clínica Veterinária.

🔧 Instalação
Clone o repositório.

Instale as dependências:

npm install

Configuração do Supabase:

Crie um projeto no Supabase.

No dashboard do Supabase (SQL Editor), aplique o seu schema.sql para criar todas as tabelas e políticas de RLS.

Crie um arquivo .env na raiz do seu projeto e preencha-o com suas credenciais do Supabase (encontradas em Project Settings -> API Keys):

SUPABASE_URL=YOUR_SUPABASE_PROJECT_URL
SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_PUBLIC_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY

Inicialize o banco de dados com dados de exemplo (opcional, mas recomendado para testes):

node database/initDatabase.js

Inicie o servidor:

npm start

Para desenvolvimento com auto-reload:

npm run dev

📚 Endpoints da API
A API agora expõe os seguintes recursos:

Usuários (/api/usuarios)
GET /api/usuarios - Listar todos os usuários

GET /api/usuarios/:id - Buscar usuário por ID

POST /api/usuarios - Criar novo usuário

PUT /api/usuarios/:id - Atualizar usuário

DELETE /api/usuarios/:id - Desativar usuário (soft delete)

Clientes (/api/clientes)
GET /api/clientes - Listar todos os clientes

GET /api/clientes/:id - Buscar cliente por ID

POST /api/clientes - Criar novo cliente

PUT /api/clientes/:id - Atualizar cliente

DELETE /api/clientes/:id - Desativar cliente (soft delete)

GET /api/clientes/:id/animais - Listar animais de um cliente

Animais (/api/animais)
GET /api/animais - Listar todos os animais (pode filtrar por id_cliente)

GET /api/animais/:id - Buscar animal por ID

POST /api/animais - Criar novo animal

PUT /api/animais/:id - Atualizar animal

DELETE /api/animais/:id - Deletar animal

GET /api/animais/:id/prontuarios - Listar prontuários de um animal

Prontuários (/api/prontuarios)
GET /api/prontuarios - Listar todos os prontuários (pode filtrar por id_animal, id_veterinario, tipo_atendimento)

GET /api/prontuarios/:id - Buscar prontuário por ID

POST /api/prontuarios - Criar novo prontuário

PUT /api/prontuarios/:id - Atualizar prontuário

DELETE /api/prontuarios/:id - Deletar prontuário (inclui deleção de dependências)

GET /api/prontuarios/:id/prescricoes - Listar prescrições de um prontuário

GET /api/prontuarios/:id/vacinas - Listar vacinas de um prontuário

GET /api/prontuarios/:id/anexos - Listar anexos de um prontuário

GET /api/prontuarios/:id/fatura - Buscar fatura associada a um prontuário

Prescrições (/api/prescricoes)
GET /api/prescricoes - Listar todas as prescrições (pode filtrar por id_prontuario)

GET /api/prescricoes/:id - Buscar prescrição por ID

POST /api/prescricoes - Criar nova prescrição

PUT /api/prescricoes/:id - Atualizar prescrição

DELETE /api/prescricoes/:id - Deletar prescrição

Vacinas (/api/vacinas)
GET /api/vacinas - Listar todas as vacinas (pode filtrar por id_prontuario, nome_vacina, data_aplicacao)

GET /api/vacinas/:id - Buscar vacina por ID

POST /api/vacinas - Criar novo registro de vacina

PUT /api/vacinas/:id - Atualizar registro de vacina

DELETE /api/vacinas/:id - Deletar registro de vacina

Anexos de Prontuário (/api/anexos-prontuario)
GET /api/anexos-prontuario - Listar todos os anexos (pode filtrar por id_prontuario, tipo_arquivo)

GET /api/anexos-prontuario/:id - Buscar anexo por ID

POST /api/anexos-prontuario - Criar novo anexo

PUT /api/anexos-prontuario/:id - Atualizar anexo

DELETE /api/anexos-prontuario/:id - Deletar anexo

Agendamentos (/api/agendamentos)
GET /api/agendamentos - Listar todos os agendamentos (pode filtrar por id_animal, id_cliente, id_veterinario, status_agendamento, data_hora_inicio_apos, data_hora_fim_antes)

GET /api/agendamentos/:id - Buscar agendamento por ID

POST /api/agendamentos - Criar novo agendamento

PUT /api/agendamentos/:id - Atualizar agendamento

DELETE /api/agendamentos/:id - Cancelar agendamento (soft delete)

Produtos (/api/produtos)
GET /api/produtos - Listar todos os produtos (pode filtrar por nome, ativo)

GET /api/produtos/:id - Buscar produto por ID

POST /api/produtos - Criar novo produto

PUT /api/produtos/:id - Atualizar produto

DELETE /api/produtos/:id - Desativar produto (soft delete)

GET /api/produtos/:id/lotes - Listar lotes de um produto

GET /api/produtos/:id/movimentacoes - Listar movimentações de estoque de um produto

Lotes de Produto (/api/lotes-produto)
GET /api/lotes-produto - Listar todos os lotes de produto (pode filtrar por id_produto, numero_lote, data_validade_antes)

GET /api/lotes-produto/:id - Buscar lote por ID

POST /api/lotes-produto - Criar novo lote de produto

PUT /api/lotes-produto/:id - Atualizar lote de produto

DELETE /api/lotes-produto/:id - Deletar lote de produto (com ajuste de estoque)

Movimentação de Estoque (/api/movimentacao-estoque)
GET /api/movimentacao-estoque - Listar todas as movimentações de estoque (pode filtrar por id_produto, id_lote, tipo_movimentacao, id_usuario_responsavel)

GET /api/movimentacao-estoque/:id - Buscar movimentação por ID

POST /api/movimentacao-estoque - Criar nova movimentação de estoque (com atualização de estoque do produto/lote)

PUT /api/movimentacao-estoque/:id - Atualizar movimentação de estoque (uso cauteloso)

DELETE /api/movimentacao-estoque/:id - Deletar movimentação de estoque (uso cauteloso)

Faturas (/api/faturas)
GET /api/faturas - Listar todas as faturas (pode filtrar por id_cliente, status_fatura, data_emissao_apos, data_vencimento_antes)

GET /api/faturas/:id - Buscar fatura por ID

POST /api/faturas - Criar nova fatura

PUT /api/faturas/:id - Atualizar fatura

DELETE /api/faturas/:id - Cancelar fatura (soft delete)

GET /api/faturas/:id/itens - Listar itens de uma fatura

GET /api/faturas/:id/pagamentos - Listar pagamentos de uma fatura

GET /api/faturas/:id/atendimento - Buscar atendimento (prontuário) associado a uma fatura

Itens de Fatura (/api/itens-fatura)
GET /api/itens-fatura - Listar todos os itens de fatura (pode filtrar por id_fatura, id_produto)

GET /api/itens-fatura/:id - Buscar item de fatura por ID

POST /api/itens-fatura - Criar novo item de fatura (com ajuste no valor_total da fatura)

PUT /api/itens-fatura/:id - Atualizar item de fatura (com ajuste no valor_total da fatura)

DELETE /api/itens-fatura/:id - Deletar item de fatura (com ajuste no valor_total da fatura)

Pagamentos (/api/pagamentos)
GET /api/pagamentos - Listar todos os pagamentos (pode filtrar por id_fatura, forma_pagamento)

GET /api/pagamentos/:id - Buscar pagamento por ID

POST /api/pagamentos - Criar novo pagamento (com atualização do status_fatura da fatura)

PUT /api/pagamentos/:id - Atualizar pagamento (uso cauteloso)

DELETE /api/pagamentos/:id - Deletar pagamento (uso cauteloso)

Atendimento Fatura (/api/atendimento-fatura)
GET /api/atendimento-fatura - Listar todas as ligações (pode filtrar por id_prontuario, id_fatura)

GET /api/atendimento-fatura/:id - Buscar ligação por ID

POST /api/atendimento-fatura - Criar nova ligação

PUT /api/atendimento-fatura/:id - Atualizar ligação

DELETE /api/atendimento-fatura/:id - Deletar ligação

📝 Exemplos de Uso
Criar Cliente (Tutor)
curl -X POST http://localhost:3000/api/clientes \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Sofia Mendes",
    "cpf": "999.888.777-66",
    "telefone": "(31) 98765-1234",
    "email": "sofia.mendes@email.com",
    "endereco": "Rua da Paz, 789, Centro, Belo Horizonte"
  }'

Criar Animal

# Assumindo que você já tem um id_cliente válido, substitua <ID_DO_CLIENTE>

curl -X POST http://localhost:3000/api/animais \
  -H "Content-Type: application/json" \
  -d '{
    "id_cliente": "<ID_DO_CLIENTE>",
    "nome": "Amora",
    "especie": "Canino",
    "raca": "Golden Retriever",
    "data_nascimento": "2022-01-20",
    "sexo": "F",
    "peso": 25.5,
    "observacoes": "Muito dócil, adora passear."
  }'

Criar Prontuário

# Assumindo que você já tem um id_animal e id_veterinario válidos

curl -X POST http://localhost:3000/api/prontuarios \
  -H "Content-Type: application/json" \
  -d '{
    "id_animal": "<ID_DO_ANIMAL>",
    "id_veterinario": "<ID_DO_VETERINARIO>",
    "tipo_atendimento": "Consulta Rotina",
    "anamnese": "Animal saudável, check-up anual.",
    "diagnostico": "Saudável",
    "procedimentos_realizados": "Exame físico completo, aplicação de antipulgas.",
    "observacoes": "Agendado retorno para vacina de raiva."
  }'

🛡️ Segurança
A API inclui:

Rate limiting (100 requests por 15 minutos por IP)

Helmet.js para headers de segurança

CORS configurável

Validação de entrada

Tratamento de erros

Row Level Security (RLS) no Supabase para controle de acesso refinado ao nível do banco de dados.

🗄️ Banco de Dados
O sistema utiliza PostgreSQL gerenciado via Supabase, com as seguintes tabelas principais:

usuarios

clientes

animais

prontuarios

prescricoes

vacinas

anexos_prontuario

agendamentos

produtos

lotes_produto

movimentacao_estoque

faturas

itens_fatura

pagamentos

atendimento_fatura

📊 Health Check
Acesse GET /health para verificar o status da API e sua conexão com o Supabase.

🔄 Status Codes
200 - Sucesso

201 - Criado com sucesso

204 - Sem conteúdo (deleção bem-sucedida sem retorno)

400 - Requisição inválida (erro de validação)

401 - Não autorizado (autenticação falhou)

403 - Proibido (autorização negada)

404 - Não encontrado

409 - Conflito (ex: email duplicado, item já existe)

500 - Erro interno do servidor

🚀 Deploy
Para produção, configure as variáveis de ambiente no seu ambiente de hospedagem:

PORT - Porta do servidor (padrão: 3000)

FRONTEND_URL - URL do frontend para CORS

SUPABASE_URL - URL do seu projeto Supabase

SUPABASE_ANON_KEY - Chave anon pública do seu projeto Supabase

SUPABASE_SERVICE_ROLE_KEY - Chave service_role secreta do seu projeto Supabase (use com cautela)

📄 Licença
Este projeto está sob a licença ISC.

import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const vacinasController = {
  /**
   * @route GET /api/vacinas
   * @desc Busca todas as vacinas registradas. Pode ser filtrado por id_prontuario, nome_vacina ou data_aplicacao.
   * @access Restrito (Veterinários, Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_prontuario, nome_vacina, data_aplicacao } = req.query;
      let query = supabase.from("vacinas").select("*");

      if (id_prontuario) {
        query = query.eq("id_prontuario", id_prontuario);
      }
      if (nome_vacina) {
        query = query.ilike("nome_vacina", `%${nome_vacina}%`); // Busca por nome da vacina (case-insensitive, parcial)
      }
      if (data_aplicacao) {
        query = query.eq("data_aplicacao", data_aplicacao); // Busca por data de aplicação exata
      }

      // Ordena por data de aplicação padrão
      query = query.order("data_aplicacao", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar vacinas:", error);
        return res.status(500).json({ message: "Erro ao buscar vacinas.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em vacinasController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/vacinas/:id
   * @desc Busca uma vacina pelo ID.
   * @param {string} req.params.id - ID da vacina.
   * @access Restrito (Veterinários, Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("vacinas").select("*").eq("id_vacina", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar vacina por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar vacina.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Vacina não encontrada." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em vacinasController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/vacinas
   * @desc Cria um novo registro de vacina.
   * @param {object} req.body - Dados da vacina a ser criada.
   * @access Restrito (apenas para Veterinários)
   */
  create: async (req, res) => {
    const { id_prontuario, nome_vacina, data_aplicacao, data_proxima_dose, lote } = req.body;
    try {
      // Validação básica
      if (!id_prontuario || !nome_vacina || !data_aplicacao) {
        return res.status(400).json({ message: "ID do prontuário, nome da vacina e data de aplicação são obrigatórios." });
      }

      const { data, error } = await supabase
        .from("vacinas")
        .insert([
          {
            id_prontuario,
            nome_vacina,
            data_aplicacao,
            data_proxima_dose,
            lote,
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao registrar vacina:", error);
        return res.status(500).json({ message: "Erro ao registrar vacina.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em vacinasController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/vacinas/:id
   * @desc Atualiza um registro de vacina existente.
   * @param {string} req.params.id - ID da vacina a ser atualizada.
   * @param {object} req.body - Dados da vacina a serem atualizados.
   * @access Restrito (apenas para Veterinários)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_prontuario, nome_vacina, data_aplicacao, data_proxima_dose, lote } = req.body;
    try {
      const updatePayload = {};
      if (id_prontuario !== undefined) updatePayload.id_prontuario = id_prontuario;
      if (nome_vacina !== undefined) updatePayload.nome_vacina = nome_vacina;
      if (data_aplicacao !== undefined) updatePayload.data_aplicacao = data_aplicacao;
      if (data_proxima_dose !== undefined) updatePayload.data_proxima_dose = data_proxima_dose;
      if (lote !== undefined) updatePayload.lote = lote;

      const { data, error } = await supabase.from("vacinas").update(updatePayload).eq("id_vacina", id).select();

      if (error) {
        console.error("Erro ao atualizar vacina:", error);
        return res.status(500).json({ message: "Erro ao atualizar vacina.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Vacina não encontrada para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em vacinasController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/vacinas/:id
   * @desc Deleta um registro de vacina.
   * @param {string} req.params.id - ID da vacina a ser deletada.
   * @access Restrito (apenas para Veterinários/Gestores com cautela)
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      const { error } = await supabase.from("vacinas").delete().eq("id_vacina", id);

      if (error) {
        console.error("Erro ao deletar vacina:", error);
        return res.status(500).json({ message: "Erro ao deletar vacina.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em vacinasController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

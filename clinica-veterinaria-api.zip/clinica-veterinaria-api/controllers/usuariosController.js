import { supabase, supabaseAdmin } from "../database/database.js"; // Importa ambos os clientes Supabase
// Em uma aplicação real, você também importaria uma biblioteca para hashing de senhas, como 'bcryptjs'.
// Ex: import bcrypt from 'bcryptjs';

export const usuariosController = {
  /**
   * @route GET /api/usuarios
   * @desc Busca todos os usuários.
   * @access Restrito (apenas para Gestores ou Veterinários em alguns casos)
   */
  getAll: async (req, res) => {
    try {
      // Em um ambiente de produção, considere usar paginação e filtros.
      const { data, error } = await supabase // Usar supabase (com RLS) ou supabaseAdmin (sem RLS) dependendo do contexto da API
        .from("usuarios")
        .select("id_usuario, nome, email, perfil, ativo, data_cadastro, data_atualizacao"); // Não retorne senha_hash!

      if (error) {
        console.error("Erro ao buscar usuários:", error);
        return res.status(500).json({ message: "Erro ao buscar usuários.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em usuariosController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/usuarios/:id
   * @desc Busca um usuário pelo ID.
   * @param {string} req.params.id - ID do usuário.
   * @access Restrito (usuário pode ver a si mesmo, ou Gestores/Veterinários podem ver outros)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("usuarios").select("id_usuario, nome, email, perfil, ativo, data_cadastro, data_atualizacao").eq("id_usuario", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar usuário por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar usuário.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Usuário não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em usuariosController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/usuarios
   * @desc Cria um novo usuário.
   * @param {object} req.body - Dados do usuário a ser criado (nome, email, senha, perfil).
   * @access Restrito (apenas para Gestores)
   */
  create: async (req, res) => {
    const { nome, email, senha, perfil } = req.body;
    try {
      // Validação básica
      if (!nome || !email || !senha || !perfil) {
        return res.status(400).json({ message: "Nome, email, senha e perfil são obrigatórios." });
      }
      if (!["Veterinário", "Recepcionista", "Gestor"].includes(perfil)) {
        return res.status(400).json({ message: "Perfil inválido. Valores aceitos: 'Veterinário', 'Recepcionista', 'Gestor'." });
      }

      // Em uma aplicação real, você hashia a senha antes de salvar.
      // Ex: const senha_hash = await bcrypt.hash(senha, 10);
      const senha_hash = senha; // APENAS PARA EXEMPLO. USE HASHING EM PRODUÇÃO!

      const { data, error } = await supabaseAdmin // Usar supabaseAdmin para criar usuários (ignora RLS)
        .from("usuarios")
        .insert([{ nome, email, senha_hash, perfil }])
        .select("id_usuario, nome, email, perfil, ativo, data_cadastro, data_atualizacao"); // Não retorne a senha_hash!

      if (error) {
        console.error("Erro ao criar usuário:", error);
        // Erro de email duplicado
        if (error.code === "23505") {
          // Código de erro para violação de unique constraint
          return res.status(409).json({ message: "Email já cadastrado.", error: error.message });
        }
        return res.status(500).json({ message: "Erro ao criar usuário.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em usuariosController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/usuarios/:id
   * @desc Atualiza um usuário existente.
   * @param {string} req.params.id - ID do usuário a ser atualizado.
   * @param {object} req.body - Dados do usuário a serem atualizados.
   * @access Restrito (usuário pode atualizar a si mesmo, ou Gestores podem atualizar outros)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { nome, email, senha, perfil, ativo } = req.body;
    try {
      const updatePayload = { data_atualizacao: new Date().toISOString() };
      if (nome !== undefined) updatePayload.nome = nome;
      if (email !== undefined) updatePayload.email = email;
      if (perfil !== undefined) {
        if (!["Veterinário", "Recepcionista", "Gestor"].includes(perfil)) {
          return res.status(400).json({ message: "Perfil inválido. Valores aceitos: 'Veterinário', 'Recepcionista', 'Gestor'." });
        }
        updatePayload.perfil = perfil;
      }
      if (ativo !== undefined) updatePayload.ativo = ativo;

      // Se a senha for fornecida, ela deve ser hashada
      if (senha !== undefined) {
        // Ex: updatePayload.senha_hash = await bcrypt.hash(senha, 10);
        updatePayload.senha_hash = senha; // APENAS PARA EXEMPLO. USE HASHING EM PRODUÇÃO!
      }

      const { data, error } = await supabaseAdmin // Usar supabaseAdmin para atualizar usuários (pode ser mais seguro dependendo do RLS)
        .from("usuarios")
        .update(updatePayload)
        .eq("id_usuario", id)
        .select("id_usuario, nome, email, perfil, ativo, data_cadastro, data_atualizacao");

      if (error) {
        console.error("Erro ao atualizar usuário:", error);
        if (error.code === "23505") {
          // Código de erro para violação de unique constraint (email)
          return res.status(409).json({ message: "Email já cadastrado para outro usuário.", error: error.message });
        }
        return res.status(500).json({ message: "Erro ao atualizar usuário.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Usuário não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em usuariosController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/usuarios/:id
   * @desc Deleta (desativa) um usuário.
   * @param {string} req.params.id - ID do usuário a ser desativado.
   * @access Restrito (apenas para Gestores)
   * @note Implementado como soft delete para manter o histórico e evitar quebras de FKs.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabaseAdmin // Usar supabaseAdmin para desativar usuários
        .from("usuarios")
        .update({ ativo: false, data_atualizacao: new Date().toISOString() })
        .eq("id_usuario", id)
        .select();

      if (error) {
        console.error("Erro ao desativar usuário:", error);
        return res.status(500).json({ message: "Erro ao desativar usuário.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Usuário não encontrado para desativação." });
      }

      return res.status(200).json({ message: "Usuário desativado com sucesso.", usuario: data[0] });
    } catch (err) {
      console.error("Exceção em usuariosController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const prescricoesController = {
  /**
   * @route GET /api/prescricoes
   * @desc Busca todas as prescrições. Pode ser filtrado por id_prontuario.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getAll: async (req, res) => {
    try {
      const { id_prontuario } = req.query;
      let query = supabase.from("prescricoes").select("*");

      if (id_prontuario) {
        query = query.eq("id_prontuario", id_prontuario);
      }

      // Opcional: Ordenar por data da prescrição
      query = query.order("data_prescricao", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar prescrições:", error);
        return res.status(500).json({ message: "Erro ao buscar prescrições.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prescricoesController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prescricoes/:id
   * @desc Busca uma prescrição pelo ID.
   * @param {string} req.params.id - ID da prescrição.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("prescricoes").select("*").eq("id_prescricao", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar prescrição por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar prescrição.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Prescrição não encontrada." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prescricoesController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/prescricoes
   * @desc Cria uma nova prescrição.
   * @param {object} req.body - Dados da prescrição a ser criada.
   * @access Restrito (apenas para Veterinários)
   */
  create: async (req, res) => {
    const { id_prontuario, medicamento, dosagem, frequencia, duracao, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_prontuario || !medicamento) {
        return res.status(400).json({ message: "ID do prontuário e medicamento são obrigatórios." });
      }

      const { data, error } = await supabase
        .from("prescricoes")
        .insert([
          {
            id_prontuario,
            medicamento,
            dosagem,
            frequencia,
            duracao,
            observacoes,
            data_prescricao: new Date().toISOString(), // Preenche com a data/hora atual
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar prescrição:", error);
        return res.status(500).json({ message: "Erro ao criar prescrição.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em prescricoesController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/prescricoes/:id
   * @desc Atualiza uma prescrição existente.
   * @param {string} req.params.id - ID da prescrição a ser atualizada.
   * @param {object} req.body - Dados da prescrição a serem atualizados.
   * @access Restrito (apenas para Veterinários)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_prontuario, medicamento, dosagem, frequencia, duracao, observacoes } = req.body;
    try {
      const updatePayload = {};
      if (id_prontuario !== undefined) updatePayload.id_prontuario = id_prontuario;
      if (medicamento !== undefined) updatePayload.medicamento = medicamento;
      if (dosagem !== undefined) updatePayload.dosagem = dosagem;
      if (frequencia !== undefined) updatePayload.frequencia = frequencia;
      if (duracao !== undefined) updatePayload.duracao = duracao;
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      const { data, error } = await supabase.from("prescricoes").update(updatePayload).eq("id_prescricao", id).select();

      if (error) {
        console.error("Erro ao atualizar prescrição:", error);
        return res.status(500).json({ message: "Erro ao atualizar prescrição.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Prescrição não encontrada para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em prescricoesController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/prescricoes/:id
   * @desc Deleta uma prescrição.
   * @param {string} req.params.id - ID da prescrição a ser deletada.
   * @access Restrito (apenas para Veterinários/Gestores com cautela)
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      const { error } = await supabase.from("prescricoes").delete().eq("id_prescricao", id);

      if (error) {
        console.error("Erro ao deletar prescrição:", error);
        return res.status(500).json({ message: "Erro ao deletar prescrição.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em prescricoesController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

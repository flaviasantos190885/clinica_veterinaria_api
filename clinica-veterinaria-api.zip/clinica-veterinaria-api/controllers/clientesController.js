import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const clientesController = {
  /**
   * @route GET /api/clientes
   * @desc Busca todos os clientes.
   * @access Public
   */
  getAll: async (req, res) => {
    try {
      const { data, error } = await supabase.from("clientes").select("*"); // Seleciona todas as colunas da tabela clientes

      if (error) {
        console.error("Erro ao buscar clientes:", error);
        return res.status(500).json({ message: "Erro ao buscar clientes.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em clientesController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/clientes/:id
   * @desc Busca um cliente pelo ID.
   * @param {string} req.params.id - ID do cliente.
   * @access Public
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase
        .from("clientes")
        .select("*")
        .eq("id_cliente", id) // Filtra pelo ID do cliente
        .single(); // Espera apenas um resultado

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar cliente por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar cliente.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Cliente não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em clientesController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/clientes
   * @desc Cria um novo cliente.
   * @param {object} req.body - Dados do cliente a serem criados.
   * @access Public (ou restrito por autenticação/autorização)
   */
  create: async (req, res) => {
    const { nome, cpf, telefone, email, endereco } = req.body;
    try {
      const { data, error } = await supabase.from("clientes").insert([{ nome, cpf, telefone, email, endereco }]).select(); // Retorna os dados do cliente criado

      if (error) {
        console.error("Erro ao criar cliente:", error);
        return res.status(500).json({ message: "Erro ao criar cliente.", error: error.message });
      }

      return res.status(201).json(data[0]); // Retorna o primeiro (e único) objeto criado
    } catch (err) {
      console.error("Exceção em clientesController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/clientes/:id
   * @desc Atualiza um cliente existente.
   * @param {string} req.params.id - ID do cliente a ser atualizado.
   * @param {object} req.body - Dados do cliente a serem atualizados.
   * @access Public (ou restrito por autenticação/autorização)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { nome, cpf, telefone, email, endereco, ativo } = req.body; // Adicione 'ativo' para permitir desativar
    try {
      const { data, error } = await supabase.from("clientes").update({ nome, cpf, telefone, email, endereco, ativo, data_atualizacao: new Date().toISOString() }).eq("id_cliente", id).select();

      if (error) {
        console.error("Erro ao atualizar cliente:", error);
        return res.status(500).json({ message: "Erro ao atualizar cliente.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Cliente não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em clientesController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/clientes/:id
   * @desc Deleta um cliente (ou o desativa).
   * @param {string} req.params.id - ID do cliente a ser deletado.
   * @access Public (ou restrito por autenticação/autorização)
   * @note Considere uma deleção "suave" (soft delete) atualizando 'ativo' para false,
   * para manter o histórico de prontuários.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Opção 1: Soft delete (recomendado para dados sensíveis como clientes)
      const { data, error } = await supabase.from("clientes").update({ ativo: false, data_atualizacao: new Date().toISOString() }).eq("id_cliente", id).select();

      if (error) {
        console.error("Erro ao desativar cliente:", error);
        return res.status(500).json({ message: "Erro ao desativar cliente.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Cliente não encontrado para desativação." });
      }

      return res.status(200).json({ message: "Cliente desativado com sucesso.", cliente: data[0] });

      /*
            // Opção 2: Hard delete (deleta o registro permanentemente)
            // CUIDADO: Isso pode violar restrições de chave estrangeira se houver animais, prontuários, etc.
            const { error: deleteError } = await supabase
                .from('clientes')
                .delete()
                .eq('id_cliente', id);

            if (deleteError) {
                console.error("Erro ao deletar cliente:", deleteError);
                return res.status(500).json({ message: "Erro ao deletar cliente.", error: deleteError.message });
            }

            return res.status(204).send(); // No Content
            */
    } catch (err) {
      console.error("Exceção em clientesController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/clientes/:id/animais
   * @desc Busca todos os animais de um cliente específico.
   * @param {string} req.params.id - ID do cliente.
   * @access Public
   */
  getAnimais: async (req, res) => {
    // Renomeado de getVeiculos para getAnimais
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("animais").select("*").eq("id_cliente", id); // Filtra os animais pelo ID do cliente

      if (error) {
        console.error("Erro ao buscar animais do cliente:", error);
        return res.status(500).json({ message: "Erro ao buscar animais do cliente.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Nenhum animal encontrado para este cliente." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em clientesController.getAnimais:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const produtosController = {
  /**
   * @route GET /api/produtos
   * @desc Busca todos os produtos. Pode ser filtrado por nome ou status (ativo/inativo).
   * @access Restrito (Gestores, Recepcionistas, Veterinários)
   */
  getAll: async (req, res) => {
    try {
      const { nome, ativo } = req.query;
      let query = supabase.from("produtos").select("*");

      if (nome) {
        query = query.ilike("nome", `%${nome}%`); // Busca por nome (case-insensitive, parcial)
      }
      if (ativo !== undefined) {
        query = query.eq("ativo", activo === "true"); // Converte string para boolean
      }

      // Opcional: Adicionar ordenação padrão, por exemplo, por nome
      query = query.order("nome", { ascending: true });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar produtos:", error);
        return res.status(500).json({ message: "Erro ao buscar produtos.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em produtosController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/produtos/:id
   * @desc Busca um produto pelo ID.
   * @param {string} req.params.id - ID do produto.
   * @access Restrito (Gestores, Recepcionistas, Veterinários)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("produtos").select("*").eq("id_produto", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar produto por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar produto.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Produto não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em produtosController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/produtos
   * @desc Cria um novo produto.
   * @param {object} req.body - Dados do produto a ser criado.
   * @access Restrito (Gestores, Recepcionistas)
   */
  create: async (req, res) => {
    const { nome, descricao, preco_venda, unidade_medida, estoque_atual, estoque_minimo, ativo } = req.body;
    try {
      // Validação básica
      if (!nome || preco_venda === undefined) {
        return res.status(400).json({ message: "Nome e preço de venda são obrigatórios." });
      }

      const { data, error } = await supabase
        .from("produtos")
        .insert([
          {
            nome,
            descricao,
            preco_venda,
            unidade_medida,
            // Garante que valores padrão sejam aplicados se não fornecidos
            estoque_atual: estoque_atual !== undefined ? estoque_atual : 0,
            estoque_minimo: estoque_minimo !== undefined ? estoque_minimo : 0,
            ativo: ativo !== undefined ? ativo : true,
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar produto:", error);
        return res.status(500).json({ message: "Erro ao criar produto.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em produtosController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/produtos/:id
   * @desc Atualiza um produto existente.
   * @param {string} req.params.id - ID do produto a ser atualizado.
   * @param {object} req.body - Dados do produto a serem atualizados.
   * @access Restrito (Gestores, Recepcionistas)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { nome, descricao, preco_venda, unidade_medida, estoque_atual, estoque_minimo, ativo } = req.body;
    try {
      const updatePayload = { data_atualizacao: new Date().toISOString() };
      if (nome !== undefined) updatePayload.nome = nome;
      if (descricao !== undefined) updatePayload.descricao = descricao;
      if (preco_venda !== undefined) updatePayload.preco_venda = preco_venda;
      if (unidade_medida !== undefined) updatePayload.unidade_medida = unidade_medida;
      if (estoque_atual !== undefined) updatePayload.estoque_atual = estoque_atual;
      if (estoque_minimo !== undefined) updatePayload.estoque_minimo = estoque_minimo;
      if (ativo !== undefined) updatePayload.ativo = ativo;

      const { data, error } = await supabase.from("produtos").update(updatePayload).eq("id_produto", id).select();

      if (error) {
        console.error("Erro ao atualizar produto:", error);
        return res.status(500).json({ message: "Erro ao atualizar produto.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Produto não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em produtosController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/produtos/:id
   * @desc Deleta (desativa) um produto.
   * @param {string} req.params.id - ID do produto a ser desativado.
   * @access Restrito (Gestores)
   * @note Implementado como soft delete.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Soft delete: atualiza o campo 'ativo' para false
      const { data, error } = await supabase.from("produtos").update({ ativo: false, data_atualizacao: new Date().toISOString() }).eq("id_produto", id).select();

      if (error) {
        console.error("Erro ao desativar produto:", error);
        return res.status(500).json({ message: "Erro ao desativar produto.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Produto não encontrado para desativação." });
      }

      return res.status(200).json({ message: "Produto desativado com sucesso.", produto: data[0] });
    } catch (err) {
      console.error("Exceção em produtosController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/produtos/:id/lotes
   * @desc Busca todos os lotes de um produto específico.
   * @param {string} req.params.id - ID do produto.
   * @access Restrito (Gestores, Recepcionistas, Veterinários)
   */
  getLotes: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("lotes_produto").select("*").eq("id_produto", id);

      if (error) {
        console.error("Erro ao buscar lotes do produto:", error);
        return res.status(500).json({ message: "Erro ao buscar lotes do produto.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em produtosController.getLotes:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/produtos/:id/movimentacoes
   * @desc Busca todas as movimentações de estoque de um produto específico.
   * @param {string} req.params.id - ID do produto.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getMovimentacoes: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("movimentacao_estoque").select("*").eq("id_produto", id);

      if (error) {
        console.error("Erro ao buscar movimentações de estoque do produto:", error);
        return res.status(500).json({ message: "Erro ao buscar movimentações de estoque do produto.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em produtosController.getMovimentacoes:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

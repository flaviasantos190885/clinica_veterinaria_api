import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const lotesProdutoController = {
  /**
   * @route GET /api/lotes-produto
   * @desc Busca todos os lotes de produto. Pode ser filtrado por id_produto, numero_lote ou data_validade.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_produto, numero_lote, data_validade_antes } = req.query;
      let query = supabase.from("lotes_produto").select("*");

      if (id_produto) {
        query = query.eq("id_produto", id_produto);
      }
      if (numero_lote) {
        query = query.ilike("numero_lote", `%${numero_lote}%`); // Busca por número do lote (case-insensitive, parcial)
      }
      if (data_validade_antes) {
        query = query.lte("data_validade", data_validade_antes); // Lotes com validade até esta data
      }

      // Ordena por data de validade padrão
      query = query.order("data_validade", { ascending: true });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar lotes de produto:", error);
        return res.status(500).json({ message: "Erro ao buscar lotes de produto.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em lotesProdutoController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/lotes-produto/:id
   * @desc Busca um lote de produto pelo ID.
   * @param {string} req.params.id - ID do lote.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("lotes_produto").select("*").eq("id_lote", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar lote de produto por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar lote de produto.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Lote de produto não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em lotesProdutoController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/lotes-produto
   * @desc Cria um novo lote de produto.
   * @param {object} req.body - Dados do lote a ser criado.
   * @access Restrito (apenas para Gestores, Recepcionistas)
   */
  create: async (req, res) => {
    const { id_produto, numero_lote, data_validade, quantidade_inicial, quantidade_disponivel } = req.body;
    try {
      // Validação básica
      if (!id_produto || !numero_lote || !data_validade || quantidade_inicial === undefined) {
        return res.status(400).json({ message: "ID do produto, número do lote, data de validade e quantidade inicial são obrigatórios." });
      }

      // Garante que quantidade_disponivel seja pelo menos a quantidade_inicial se não fornecida
      const finalQuantidadeDisponivel = quantidade_disponivel !== undefined ? quantidade_disponivel : quantidade_inicial;

      const { data, error } = await supabase
        .from("lotes_produto")
        .insert([
          {
            id_produto,
            numero_lote,
            data_validade,
            quantidade_inicial,
            quantidade_disponivel: finalQuantidadeDisponivel,
            data_entrada: new Date().toISOString(),
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar lote de produto:", error);
        return res.status(500).json({ message: "Erro ao criar lote de produto.", error: error.message });
      }

      // Opcional: Atualizar o estoque_atual do produto correspondente
      await supabase
        .from("produtos")
        .update({ estoque_atual: supabase.raw(`estoque_atual + ${finalQuantidadeDisponivel}`) })
        .eq("id_produto", id_produto);

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em lotesProdutoController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/lotes-produto/:id
   * @desc Atualiza um lote de produto existente.
   * @param {string} req.params.id - ID do lote a ser atualizado.
   * @param {object} req.body - Dados do lote a serem atualizados (ex: quantidade_disponivel).
   * @access Restrito (apenas para Gestores, Recepcionistas)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_produto, numero_lote, data_validade, quantidade_inicial, quantidade_disponivel } = req.body;
    try {
      const updatePayload = {};
      if (id_produto !== undefined) updatePayload.id_produto = id_produto;
      if (numero_lote !== undefined) updatePayload.numero_lote = numero_lote;
      if (data_validade !== undefined) updatePayload.data_validade = data_validade;
      if (quantidade_inicial !== undefined) updatePayload.quantidade_inicial = quantidade_inicial;
      if (quantidade_disponivel !== undefined) updatePayload.quantidade_disponivel = quantidade_disponivel;

      const { data, error } = await supabase.from("lotes_produto").update(updatePayload).eq("id_lote", id).select();

      if (error) {
        console.error("Erro ao atualizar lote de produto:", error);
        return res.status(500).json({ message: "Erro ao atualizar lote de produto.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Lote de produto não encontrado para atualização." });
      }

      // Lógica para ajustar o estoque_atual do produto pode ser mais complexa aqui,
      // pois depende da diferença entre a quantidade_disponivel antiga e a nova.
      // Para simplicidade, não vou adicionar a lógica de ajuste de estoque_atual aqui,
      // mas é algo a ser considerado para a tabela 'movimentacao_estoque'.

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em lotesProdutoController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/lotes-produto/:id
   * @desc Deleta um lote de produto.
   * @param {string} req.params.id - ID do lote a ser deletado.
   * @access Restrito (apenas para Gestores com cautela)
   * @note A deleção deve ser tratada com cautela, especialmente se houver movimentações de estoque vinculadas.
   * Pode ser preferível invalidar o lote ou ajustar seu estoque para zero.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Opcional: Antes de deletar o lote, registrar uma movimentação de "ajuste negativo"
      // para retirar a quantidade restante do estoque do produto.
      // Primeiro, obter a quantidade disponível do lote
      const { data: loteData, error: loteError } = await supabase.from("lotes_produto").select("id_produto, quantidade_disponivel").eq("id_lote", id).single();

      if (loteError && loteError.code !== "PGRST116") {
        console.error("Erro ao obter lote para deleção:", loteError.message);
        return res.status(500).json({ message: "Erro ao preparar deleção do lote.", error: loteError.message });
      }

      if (loteData && loteData.quantidade_disponivel > 0) {
        // Diminuir o estoque_atual do produto
        await supabase
          .from("produtos")
          .update({ estoque_atual: supabase.raw(`estoque_atual - ${loteData.quantidade_disponivel}`) })
          .eq("id_produto", loteData.id_produto);

        // Registrar a movimentação de estoque
        await supabase.from("movimentacao_estoque").insert([
          {
            id_produto: loteData.id_produto,
            id_lote: id,
            tipo_movimentacao: "Ajuste_Negativo",
            quantidade: loteData.quantidade_disponivel,
            id_usuario_responsavel: null, // Ajuste para o ID do usuário logado
            observacoes: `Remoção do lote ${loteData.numero_lote || id} (deleção)`,
          },
        ]);
      }

      const { error } = await supabase.from("lotes_produto").delete().eq("id_lote", id);

      if (error) {
        console.error("Erro ao deletar lote de produto:", error);
        return res.status(500).json({ message: "Erro ao deletar lote de produto.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em lotesProdutoController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const agendamentosController = {
  /**
   * @route GET /api/agendamentos
   * @desc Busca todos os agendamentos. Pode ser filtrado por id_animal, id_cliente, id_veterinario,
   * status_agendamento, e intervalo de datas (data_hora_inicio_apos, data_hora_fim_antes).
   * @access Restrito (Recepcionistas, Veterinários, Gestores)
   */
  getAll: async (req, res) => {
    try {
      const { id_animal, id_cliente, id_veterinario, status_agendamento, data_hora_inicio_apos, data_hora_fim_antes } = req.query;
      let query = supabase.from("agendamentos").select("*");

      if (id_animal) {
        query = query.eq("id_animal", id_animal);
      }
      if (id_cliente) {
        query = query.eq("id_cliente", id_cliente);
      }
      if (id_veterinario) {
        query = query.eq("id_veterinario", id_veterinario);
      }
      if (status_agendamento) {
        query = query.eq("status_agendamento", status_agendamento);
      }
      if (data_hora_inicio_apos) {
        query = query.gte("data_hora_inicio", data_hora_inicio_apos);
      }
      if (data_hora_fim_antes) {
        query = query.lte("data_hora_fim", data_hora_fim_antes);
      }

      // Ordena por data e hora de início padrão
      query = query.order("data_hora_inicio", { ascending: true });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar agendamentos:", error);
        return res.status(500).json({ message: "Erro ao buscar agendamentos.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em agendamentosController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/agendamentos/:id
   * @desc Busca um agendamento pelo ID.
   * @param {string} req.params.id - ID do agendamento.
   * @access Restrito (Recepcionistas, Veterinários, Gestores)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("agendamentos").select("*").eq("id_agendamento", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar agendamento por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar agendamento.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Agendamento não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em agendamentosController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/agendamentos
   * @desc Cria um novo agendamento.
   * @param {object} req.body - Dados do agendamento a ser criado.
   * @access Restrito (Recepcionistas, Veterinários)
   */
  create: async (req, res) => {
    const { id_animal, id_cliente, id_veterinario, data_hora_inicio, data_hora_fim, tipo_agendamento, status_agendamento, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_animal || !id_cliente || !id_veterinario || !data_hora_inicio || !data_hora_fim || !tipo_agendamento) {
        return res.status(400).json({ message: "Todos os campos obrigatórios (animal, cliente, veterinário, datas, tipo) devem ser fornecidos." });
      }
      if (new Date(data_hora_inicio) >= new Date(data_hora_fim)) {
        return res.status(400).json({ message: "A data/hora de início deve ser anterior à data/hora de fim." });
      }

      const { data, error } = await supabase
        .from("agendamentos")
        .insert([
          {
            id_animal,
            id_cliente,
            id_veterinario,
            data_hora_inicio: data_hora_inicio, // Assume que vem em formato ISO string
            data_hora_fim: data_hora_fim, // Assume que vem em formato ISO string
            tipo_agendamento,
            status_agendamento: status_agendamento || "Agendado", // Define padrão se não fornecido
            observacoes,
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar agendamento:", error);
        return res.status(500).json({ message: "Erro ao criar agendamento.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em agendamentosController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/agendamentos/:id
   * @desc Atualiza um agendamento existente.
   * @param {string} req.params.id - ID do agendamento a ser atualizado.
   * @param {object} req.body - Dados do agendamento a serem atualizados.
   * @access Restrito (Recepcionistas, Veterinários)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_animal, id_cliente, id_veterinario, data_hora_inicio, data_hora_fim, tipo_agendamento, status_agendamento, observacoes } = req.body;
    try {
      const updatePayload = { data_atualizacao: new Date().toISOString() };
      if (id_animal !== undefined) updatePayload.id_animal = id_animal;
      if (id_cliente !== undefined) updatePayload.id_cliente = id_cliente;
      if (id_veterinario !== undefined) updatePayload.id_veterinario = id_veterinario;
      if (data_hora_inicio !== undefined) updatePayload.data_hora_inicio = data_hora_inicio;
      if (data_hora_fim !== undefined) updatePayload.data_hora_fim = data_hora_fim;
      if (tipo_agendamento !== undefined) updatePayload.tipo_agendamento = tipo_agendamento;
      if (status_agendamento !== undefined) {
        if (!["Agendado", "Confirmado", "Cancelado", "Realizado"].includes(status_agendamento)) {
          return res.status(400).json({ message: "Status de agendamento inválido." });
        }
        updatePayload.status_agendamento = status_agendamento;
      }
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      // Validação de datas se ambas forem fornecidas para garantir que início < fim
      if (updatePayload.data_hora_inicio && updatePayload.data_hora_fim && new Date(updatePayload.data_hora_inicio) >= new Date(updatePayload.data_hora_fim)) {
        return res.status(400).json({ message: "A data/hora de início deve ser anterior à data/hora de fim." });
      }

      const { data, error } = await supabase.from("agendamentos").update(updatePayload).eq("id_agendamento", id).select();

      if (error) {
        console.error("Erro ao atualizar agendamento:", error);
        return res.status(500).json({ message: "Erro ao atualizar agendamento.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Agendamento não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em agendamentosController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/agendamentos/:id
   * @desc Deleta um agendamento.
   * @param {string} req.params.id - ID do agendamento a ser deletado.
   * @access Restrito (Recepcionistas, Gestores)
   * @note Considere mudar o status para 'Cancelado' (soft delete) em vez de deletar o registro.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Opção 1: Soft delete (mudar status para 'Cancelado')
      const { data, error } = await supabase.from("agendamentos").update({ status_agendamento: "Cancelado", data_atualizacao: new Date().toISOString() }).eq("id_agendamento", id).select();

      if (error) {
        console.error("Erro ao cancelar agendamento:", error);
        return res.status(500).json({ message: "Erro ao cancelar agendamento.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Agendamento não encontrado para cancelamento." });
      }

      return res.status(200).json({ message: "Agendamento cancelado com sucesso.", agendamento: data[0] });

      /*
            // Opção 2: Hard delete (deleta o registro permanentemente)
            const { error: hardDeleteError } = await supabase
                .from('agendamentos')
                .delete()
                .eq('id_agendamento', id);

            if (hardDeleteError) {
                console.error("Erro ao deletar agendamento:", hardDeleteError);
                return res.status(500).json({ message: "Erro ao deletar agendamento.", error: hardDeleteError.message });
            }

            return res.status(204).send(); // No Content
            */
    } catch (err) {
      console.error("Exceção em agendamentosController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

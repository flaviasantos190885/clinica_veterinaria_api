import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const pagamentosController = {
  /**
   * @route GET /api/pagamentos
   * @desc Busca todos os pagamentos. Pode ser filtrado por id_fatura ou forma_pagamento.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_fatura, forma_pagamento } = req.query;
      let query = supabase.from("pagamentos").select("*");

      if (id_fatura) {
        query = query.eq("id_fatura", id_fatura);
      }
      if (forma_pagamento) {
        query = query.eq("forma_pagamento", forma_pagamento);
      }

      // Opcional: Ordenar por data de pagamento
      query = query.order("data_pagamento", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar pagamentos:", error);
        return res.status(500).json({ message: "Erro ao buscar pagamentos.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em pagamentosController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/pagamentos/:id
   * @desc Busca um pagamento pelo ID.
   * @param {string} req.params.id - ID do pagamento.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("pagamentos").select("*").eq("id_pagamento", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar pagamento por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar pagamento.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Pagamento não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em pagamentosController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/pagamentos
   * @desc Registra um novo pagamento e atualiza o status da fatura.
   * @param {object} req.body - Dados do pagamento a ser criado.
   * @access Restrito (Recepcionistas, Gestores)
   * @note A criação de pagamentos deve afetar o status e o valor pago da fatura.
   */
  create: async (req, res) => {
    const { id_fatura, valor_pago, forma_pagamento, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_fatura || valor_pago === undefined || valor_pago <= 0 || !forma_pagamento) {
        return res.status(400).json({ message: "ID da fatura, valor pago (positivo) e forma de pagamento são obrigatórios." });
      }

      // 1. Obter os detalhes da fatura para verificar o saldo
      const { data: faturaData, error: faturaError } = await supabase.from("faturas").select("valor_total, status_fatura").eq("id_fatura", id_fatura).single();

      if (faturaError && faturaError.code !== "PGRST116") throw faturaError;
      if (!faturaData) return res.status(404).json({ message: "Fatura não encontrada." });

      if (faturaData.status_fatura === "Paga" || faturaData.status_fatura === "Cancelada") {
        return res.status(400).json({ message: "Não é possível registrar pagamento para uma fatura já paga ou cancelada." });
      }

      // 2. Registrar o pagamento
      const { data: pagamentoData, error: pagamentoInsertError } = await supabase
        .from("pagamentos")
        .insert([
          {
            id_fatura,
            data_pagamento: new Date().toISOString(),
            valor_pago,
            forma_pagamento,
            observacoes,
          },
        ])
        .select();

      if (pagamentoInsertError) {
        console.error("Erro ao registrar pagamento:", pagamentoInsertError);
        throw pagamentoInsertError;
      }

      // 3. Atualizar o valor_total da fatura e seu status
      // Pode ser necessário somar os pagamentos existentes para calcular o valor_restante_a_pagar
      const { data: totalPagoResult, error: totalPagoError } = await supabase.from("pagamentos").select("valor_pago").eq("id_fatura", id_fatura);

      if (totalPagoError) throw totalPagoError;

      const totalPagoAteAgora = totalPagoResult.reduce((sum, p) => sum + p.valor_pago, 0);
      const saldoDevedor = faturaData.valor_total - totalPagoAteAgora;

      let newStatusFatura = "Parcialmente_Paga";
      if (saldoDevedor <= 0) {
        newStatusFatura = "Paga";
      } else if (totalPagoAteAgora === 0) {
        // Pode acontecer se o pagamento atual é o único e parcial
        newStatusFatura = "Pendente"; // Mantém Pendente ou 'Parcialmente_Paga'
      }

      const { error: updateFaturaError } = await supabase.from("faturas").update({ status_fatura: newStatusFatura }).eq("id_fatura", id_fatura);

      if (updateFaturaError) {
        console.error("Erro ao atualizar status da fatura:", updateFaturaError);
        throw updateFaturaError;
      }

      return res.status(201).json(pagamentoData[0]);
    } catch (err) {
      console.error("Exceção em pagamentosController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor ou falha na transação de pagamento.", error: err.message });
    }
  },

  /**
   * @route PUT /api/pagamentos/:id
   * @desc Atualiza um pagamento existente.
   * @param {string} req.params.id - ID do pagamento a ser atualizado.
   * @param {object} req.body - Dados do pagamento a serem atualizados.
   * @access Restrito (apenas para Gestores com extrema cautela)
   * @note A atualização de pagamentos é sensível e pode desequilibrar o status da fatura.
   * A lógica para reajustar o status da fatura NÃO está implementada aqui para complexidade.
   * Geralmente, estornos ou ajustes são feitos com novas movimentações financeiras.
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_fatura, valor_pago, forma_pagamento, observacoes } = req.body;
    try {
      const updatePayload = {};
      if (id_fatura !== undefined) updatePayload.id_fatura = id_fatura;
      if (valor_pago !== undefined) updatePayload.valor_pago = valor_pago;
      if (forma_pagamento !== undefined) updatePayload.forma_pagamento = forma_pagamento;
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      // AVISO: A lógica para reajustar o status da fatura ao alterar um pagamento existente é complexa
      // e NÃO está implementada aqui. Recomenda-se criar um novo registro de pagamento/estorno
      // para manter um histórico financeiro transparente.

      const { data, error } = await supabase.from("pagamentos").update(updatePayload).eq("id_pagamento", id).select();

      if (error) {
        console.error("Erro ao atualizar pagamento:", error);
        return res.status(500).json({ message: "Erro ao atualizar pagamento.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Pagamento não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em pagamentosController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/pagamentos/:id
   * @desc Deleta um registro de pagamento.
   * @param {string} req.params.id - ID do pagamento a ser deletado.
   * @access Restrito (apenas para Gestores com extrema cautela)
   * @note A deleção de pagamentos é altamente desaconselhada. Geralmente, estornos são feitos com novas movimentações.
   * Se deletado, a reversão do status da fatura NÃO está implementada aqui.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // AVISO: A remoção de um pagamento do histórico é perigosa para a integridade financeira.
      // Para manter a integridade, você precisaria reverter o efeito desse pagamento no status da fatura.
      // Essa lógica de reversão NÃO está implementada aqui.
      // Considere fortemente desabilitar a deleção de pagamentos históricos.

      // Opcional: Obter o valor pago e o id_fatura antes de deletar para ajustar o status da fatura
      const { data: pagamentoData, error: getPagamentoError } = await supabase.from("pagamentos").select("id_fatura, valor_pago").eq("id_pagamento", id).single();

      if (getPagamentoError && getPagamentoError.code !== "PGRST116") throw getPagamentoError;
      if (!pagamentoData) return res.status(404).json({ message: "Pagamento não encontrado para deleção." });

      const { error } = await supabase.from("pagamentos").delete().eq("id_pagamento", id);

      if (error) {
        console.error("Erro ao deletar pagamento:", error);
        return res.status(500).json({ message: "Erro ao deletar pagamento.", error: error.message });
      }

      // Lógica para recalcular o status da fatura (opcional, mas recomendado)
      const { data: remainingPayments, error: remainingPaymentsError } = await supabase.from("pagamentos").select("valor_pago").eq("id_fatura", pagamentoData.id_fatura);

      if (remainingPaymentsError) throw remainingPaymentsError;

      const totalPagoAtualizado = remainingPayments.reduce((sum, p) => sum + p.valor_pago, 0);

      const { data: faturaOriginal, error: faturaOriginalError } = await supabase.from("faturas").select("valor_total").eq("id_fatura", pagamentoData.id_fatura).single();

      if (faturaOriginalError) throw faturaOriginalError;

      let newStatusFatura = "Pendente";
      if (totalPagoAtualizado > 0 && totalPagoAtualizado < faturaOriginal.valor_total) {
        newStatusFatura = "Parcialmente_Paga";
      } else if (totalPagoAtualizado >= faturaOriginal.valor_total) {
        newStatusFatura = "Paga";
      }

      await supabase.from("faturas").update({ status_fatura: newStatusFatura }).eq("id_fatura", pagamentoData.id_fatura);

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em pagamentosController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

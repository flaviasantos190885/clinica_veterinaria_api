import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const atendimentoFaturaController = {
  /**
   * @route GET /api/atendimento-fatura
   * @desc Busca todas as ligações entre atendimento e fatura. Pode ser filtrado por id_prontuario ou id_fatura.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_prontuario, id_fatura } = req.query;
      let query = supabase.from("atendimento_fatura").select("*");

      if (id_prontuario) {
        query = query.eq("id_prontuario", id_prontuario);
      }
      if (id_fatura) {
        query = query.eq("id_fatura", id_fatura);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar ligações atendimento-fatura:", error);
        return res.status(500).json({ message: "Erro ao buscar ligações atendimento-fatura.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em atendimentoFaturaController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/atendimento-fatura/:id
   * @desc Busca uma ligação atendimento-fatura pelo ID.
   * @param {string} req.params.id - ID da ligação.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("atendimento_fatura").select("*").eq("id_atendimento_fatura", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar ligação atendimento-fatura por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar ligação atendimento-fatura.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Ligação atendimento-fatura não encontrada." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em atendimentoFaturaController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/atendimento-fatura
   * @desc Cria uma nova ligação entre atendimento e fatura.
   * @param {object} req.body - Dados da ligação a ser criada (id_prontuario, id_fatura).
   * @access Restrito (Recepcionistas, Gestores)
   */
  create: async (req, res) => {
    const { id_prontuario, id_fatura } = req.body;
    try {
      // Validação básica
      if (!id_prontuario || !id_fatura) {
        return res.status(400).json({ message: "ID do prontuário e ID da fatura são obrigatórios." });
      }

      const { data, error } = await supabase.from("atendimento_fatura").insert([{ id_prontuario, id_fatura }]).select();

      if (error) {
        console.error("Erro ao criar ligação atendimento-fatura:", error);
        // Tratar erro de "unique constraint" se a combinação já existir
        if (error.code === "23505") {
          return res.status(409).json({ message: "Esta ligação entre prontuário e fatura já existe.", error: error.message });
        }
        return res.status(500).json({ message: "Erro ao criar ligação atendimento-fatura.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em atendimentoFaturaController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/atendimento-fatura/:id
   * @desc Atualiza uma ligação atendimento-fatura existente.
   * @param {string} req.params.id - ID da ligação a ser atualizada.
   * @param {object} req.body - Dados da ligação a serem atualizados.
   * @access Restrito (Recepcionistas, Gestores)
   * @note Atualizar uma ligação de fatura raramente é necessário, pois geralmente é uma relação 1:1.
   * Pode ser mais comum deletar e recriar se a associação estiver incorreta.
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_prontuario, id_fatura } = req.body;
    try {
      const updatePayload = {};
      if (id_prontuario !== undefined) updatePayload.id_prontuario = id_prontuario;
      if (id_fatura !== undefined) updatePayload.id_fatura = id_fatura;

      const { data, error } = await supabase.from("atendimento_fatura").update(updatePayload).eq("id_atendimento_fatura", id).select();

      if (error) {
        console.error("Erro ao atualizar ligação atendimento-fatura:", error);
        if (error.code === "23505") {
          // Erro de unique constraint
          return res.status(409).json({ message: "Esta combinação de prontuário e fatura já existe.", error: error.message });
        }
        return res.status(500).json({ message: "Erro ao atualizar ligação atendimento-fatura.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Ligação atendimento-fatura não encontrada para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em atendimentoFaturaController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/atendimento-fatura/:id
   * @desc Deleta uma ligação atendimento-fatura.
   * @param {string} req.params.id - ID da ligação a ser deletada.
   * @access Restrito (apenas para Gestores com cautela)
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      const { error } = await supabase.from("atendimento_fatura").delete().eq("id_atendimento_fatura", id);

      if (error) {
        console.error("Erro ao deletar ligação atendimento-fatura:", error);
        return res.status(500).json({ message: "Erro ao deletar ligação atendimento-fatura.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em atendimentoFaturaController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

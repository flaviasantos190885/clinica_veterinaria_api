import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const itensFaturaController = {
  /**
   * @route GET /api/itens-fatura
   * @desc Busca todos os itens de fatura. Pode ser filtrado por id_fatura ou id_produto.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_fatura, id_produto } = req.query;
      let query = supabase.from("itens_fatura").select("*");

      if (id_fatura) {
        query = query.eq("id_fatura", id_fatura);
      }
      if (id_produto) {
        query = query.eq("id_produto", id_produto);
      }

      // Opcional: Ordenar por valor total do item
      query = query.order("valor_total_item", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar itens de fatura:", error);
        return res.status(500).json({ message: "Erro ao buscar itens de fatura.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em itensFaturaController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/itens-fatura/:id
   * @desc Busca um item de fatura pelo ID.
   * @param {string} req.params.id - ID do item de fatura.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("itens_fatura").select("*").eq("id_item_fatura", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar item de fatura por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar item de fatura.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Item de fatura não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em itensFaturaController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/itens-fatura
   * @desc Cria um novo item de fatura.
   * @param {object} req.body - Dados do item de fatura a ser criado.
   * @access Restrito (Recepcionistas, Gestores)
   * @note A criação de itens de fatura deve atualizar o valor_total na fatura principal.
   */
  create: async (req, res) => {
    const { id_fatura, id_produto, descricao_servico, quantidade, valor_unitario } = req.body;
    try {
      // Validação básica
      if (!id_fatura || (id_produto === undefined && !descricao_servico) || quantidade === undefined || valor_unitario === undefined) {
        return res.status(400).json({ message: "ID da fatura, produto/serviço, quantidade e valor unitário são obrigatórios." });
      }

      // Calcular valor total do item
      const valor_total_item = quantidade * valor_unitario;

      const { data, error } = await supabase
        .from("itens_fatura")
        .insert([
          {
            id_fatura,
            id_produto: id_produto || null, // Pode ser null se for um serviço
            descricao_servico,
            quantidade,
            valor_unitario,
            valor_total_item,
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar item de fatura:", error);
        return res.status(500).json({ message: "Erro ao criar item de fatura.", error: error.message });
      }

      // Atualizar valor total da fatura
      await supabase
        .from("faturas")
        .update({ valor_total: supabase.raw(`valor_total + ${valor_total_item}`) })
        .eq("id_fatura", id_fatura);

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em itensFaturaController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/itens-fatura/:id
   * @desc Atualiza um item de fatura existente.
   * @param {string} req.params.id - ID do item de fatura a ser atualizado.
   * @param {object} req.body - Dados do item de fatura a serem atualizados.
   * @access Restrito (Recepcionistas, Gestores)
   * @note A atualização de um item de fatura deve ajustar o valor_total na fatura principal.
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_fatura, id_produto, descricao_servico, quantidade, valor_unitario } = req.body;
    try {
      // Obter o item antigo para calcular a diferença no valor total da fatura
      const { data: oldItem, error: oldItemError } = await supabase.from("itens_fatura").select("id_fatura, valor_total_item").eq("id_item_fatura", id).single();

      if (oldItemError && oldItemError.code !== "PGRST116") throw oldItemError;
      if (!oldItem) return res.status(404).json({ message: "Item de fatura não encontrado para atualização." });

      const updatePayload = {};
      let newValorTotalItem = oldItem.valor_total_item; // Valor padrão, será recalculado

      if (id_fatura !== undefined) updatePayload.id_fatura = id_fatura;
      if (id_produto !== undefined) updatePayload.id_produto = id_produto;
      if (descricao_servico !== undefined) updatePayload.descricao_servico = descricao_servico;
      if (quantidade !== undefined) updatePayload.quantidade = quantidade;
      if (valor_unitario !== undefined) updatePayload.valor_unitario = valor_unitario;

      // Recalcular valor_total_item se quantidade ou valor_unitario foram alterados
      if (quantidade !== undefined || valor_unitario !== undefined) {
        const effectiveQuantidade = quantidade !== undefined ? quantidade : oldItem.quantidade;
        const effectiveValorUnitario = valor_unitario !== undefined ? valor_unitario : oldItem.valor_unitario;
        newValorTotalItem = effectiveQuantidade * effectiveValorUnitario;
        updatePayload.valor_total_item = newValorTotalItem;
      }

      const { data, error } = await supabase.from("itens_fatura").update(updatePayload).eq("id_item_fatura", id).select();

      if (error) {
        console.error("Erro ao atualizar item de fatura:", error);
        return res.status(500).json({ message: "Erro ao atualizar item de fatura.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Item de fatura não encontrado para atualização." });
      }

      // Ajustar o valor total da fatura principal
      const valorDiferenca = newValorTotalItem - oldItem.valor_total_item;
      if (valorDiferenca !== 0) {
        await supabase
          .from("faturas")
          .update({ valor_total: supabase.raw(`valor_total + ${valorDiferenca}`) })
          .eq("id_fatura", oldItem.id_fatura); // Use id_fatura do item antigo
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em itensFaturaController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/itens-fatura/:id
   * @desc Deleta um item de fatura.
   * @param {string} req.params.id - ID do item de fatura a ser deletado.
   * @access Restrito (apenas para Gestores com cautela)
   * @note A deleção de um item de fatura deve ajustar o valor_total na fatura principal.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Obter o item para subtrair o valor total da fatura principal
      const { data: itemToDelete, error: itemDeleteError } = await supabase.from("itens_fatura").select("id_fatura, valor_total_item").eq("id_item_fatura", id).single();

      if (itemDeleteError && itemDeleteError.code !== "PGRST116") throw itemDeleteError;
      if (!itemToDelete) return res.status(404).json({ message: "Item de fatura não encontrado para deleção." });

      // Deletar o item da fatura
      const { error } = await supabase.from("itens_fatura").delete().eq("id_item_fatura", id);

      if (error) {
        console.error("Erro ao deletar item de fatura:", error);
        return res.status(500).json({ message: "Erro ao deletar item de fatura.", error: error.message });
      }

      // Diminuir o valor total da fatura principal
      await supabase
        .from("faturas")
        .update({ valor_total: supabase.raw(`valor_total - ${itemToDelete.valor_total_item}`) })
        .eq("id_fatura", itemToDelete.id_fatura);

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em itensFaturaController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const movimentacaoEstoqueController = {
  /**
   * @route GET /api/movimentacao-estoque
   * @desc Busca todas as movimentações de estoque. Pode ser filtrado por id_produto, id_lote, tipo_movimentacao ou id_usuario_responsavel.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_produto, id_lote, tipo_movimentacao, id_usuario_responsavel } = req.query;
      let query = supabase.from("movimentacao_estoque").select("*");

      if (id_produto) {
        query = query.eq("id_produto", id_produto);
      }
      if (id_lote) {
        query = query.eq("id_lote", id_lote);
      }
      if (tipo_movimentacao) {
        query = query.eq("tipo_movimentacao", tipo_movimentacao);
      }
      if (id_usuario_responsavel) {
        query = query.eq("id_usuario_responsavel", id_usuario_responsavel);
      }

      // Ordena por data da movimentação padrão
      query = query.order("data_movimentacao", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar movimentações de estoque:", error);
        return res.status(500).json({ message: "Erro ao buscar movimentações de estoque.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em movimentacaoEstoqueController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/movimentacao-estoque/:id
   * @desc Busca uma movimentação de estoque pelo ID.
   * @param {string} req.params.id - ID da movimentação.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("movimentacao_estoque").select("*").eq("id_movimentacao", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar movimentação de estoque por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar movimentação de estoque.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Movimentação de estoque não encontrada." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em movimentacaoEstoqueController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/movimentacao-estoque
   * @desc Cria uma nova movimentação de estoque e atualiza o estoque do produto/lote.
   * @param {object} req.body - Dados da movimentação (id_produto, quantidade, tipo_movimentacao, id_lote, id_usuario_responsavel, observacoes).
   * @access Restrito (Gestores, Recepcionistas)
   */
  create: async (req, res) => {
    const { id_produto, id_lote, tipo_movimentacao, quantidade, id_usuario_responsavel, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_produto || !tipo_movimentacao || quantidade === undefined || quantidade <= 0) {
        return res.status(400).json({ message: "ID do produto, tipo de movimentação e quantidade (positiva) são obrigatórios." });
      }
      if (!["Entrada", "Saida_Venda", "Saida_Uso", "Ajuste_Positivo", "Ajuste_Negativo"].includes(tipo_movimentacao)) {
        return res.status(400).json({ message: "Tipo de movimentação inválido." });
      }

      let newEstoqueAtual = null;
      let newQuantidadeDisponivelLote = null;

      // Transação ou manipulação de estoque otimista
      // É recomendado usar transações de banco de dados ou funções do Supabase (Edge Functions)
      // para garantir atomicidade em operações de estoque. Aqui é uma abordagem sequencial.

      // 1. Obter estoque atual do produto e quantidade disponível do lote (se houver lote)
      const { data: produtoAtual, error: produtoError } = await supabase.from("produtos").select("estoque_atual").eq("id_produto", id_produto).single();

      if (produtoError && produtoError.code !== "PGRST116") throw produtoError;
      if (!produtoAtual) return res.status(404).json({ message: "Produto não encontrado." });

      let loteAtual = null;
      if (id_lote) {
        const { data: loteData, error: loteDataError } = await supabase.from("lotes_produto").select("quantidade_disponivel").eq("id_lote", id_lote).single();
        if (loteDataError && loteDataError.code !== "PGRST116") throw loteDataError;
        if (!loteData) return res.status(404).json({ message: "Lote não encontrado." });
        loteAtual = loteData;
      }

      // 2. Calcular novo estoque e nova quantidade do lote
      switch (tipo_movimentacao) {
        case "Entrada":
        case "Ajuste_Positivo":
          newEstoqueAtual = produtoAtual.estoque_atual + quantidade;
          if (id_lote && loteAtual) newQuantidadeDisponivelLote = loteAtual.quantidade_disponivel + quantidade;
          break;
        case "Saida_Venda":
        case "Saida_Uso":
        case "Ajuste_Negativo":
          newEstoqueAtual = produtoAtual.estoque_atual - quantidade;
          if (id_lote && loteAtual) newQuantidadeDisponivelLote = loteAtual.quantidade_disponivel - quantidade;
          break;
      }

      // Validação de estoque para saídas
      if (["Saida_Venda", "Saida_Uso", "Ajuste_Negativo"].includes(tipo_movimentacao) && newEstoqueAtual < 0) {
        return res.status(400).json({ message: "Estoque insuficiente para esta movimentação." });
      }
      if (id_lote && ["Saida_Venda", "Saida_Uso", "Ajuste_Negativo"].includes(tipo_movimentacao) && newQuantidadeDisponivelLote < 0) {
        return res.status(400).json({ message: "Quantidade insuficiente no lote para esta movimentação." });
      }

      // 3. Registrar a movimentação
      const { data: movimentacaoData, error: movimentacaoError } = await supabase
        .from("movimentacao_estoque")
        .insert([
          {
            id_produto,
            id_lote: id_lote || null, // Garante que é null se não fornecido
            tipo_movimentacao,
            quantidade,
            data_movimentacao: new Date().toISOString(),
            id_usuario_responsavel: id_usuario_responsavel || null, // O ID do usuário logado viria de um middleware de autenticação
            observacoes,
          },
        ])
        .select();

      if (movimentacaoError) {
        console.error("Erro ao registrar movimentação de estoque:", movimentacaoError);
        throw movimentacaoError; // Lança para capturar no catch externo
      }

      // 4. Atualizar o estoque do produto
      const { error: updateProdutoError } = await supabase.from("produtos").update({ estoque_atual: newEstoqueAtual }).eq("id_produto", id_produto);

      if (updateProdutoError) {
        console.error("Erro ao atualizar estoque do produto:", updateProdutoError);
        throw updateProdutoError;
      }

      // 5. Atualizar a quantidade disponível no lote (se aplicável)
      if (id_lote && loteAtual) {
        const { error: updateLoteError } = await supabase.from("lotes_produto").update({ quantidade_disponivel: newQuantidadeDisponivelLote }).eq("id_lote", id_lote);

        if (updateLoteError) {
          console.error("Erro ao atualizar quantidade do lote:", updateLoteError);
          throw updateLoteError;
        }
      }

      return res.status(201).json(movimentacaoData[0]);
    } catch (err) {
      console.error("Exceção em movimentacaoEstoqueController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor ou erro de consistência de estoque.", error: err.message });
    }
  },

  /**
   * @route PUT /api/movimentacao-estoque/:id
   * @desc Atualizar uma movimentação de estoque existente (raramente usado, pois afeta o histórico).
   * @param {string} req.params.id - ID da movimentação a ser atualizada.
   * @param {object} req.body - Dados da movimentação a serem atualizados.
   * @access Restrito (apenas para Gestores com extrema cautela)
   * @note A atualização de movimentações de estoque é complexa e perigosa, pois pode desequilibrar o estoque.
   * Normalmente, "ajustes" são feitos através de novas movimentações.
   * Esta função não implementa a lógica de reverter/reaplicar o estoque no produto/lote.
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_produto, id_lote, tipo_movimentacao, quantidade, id_usuario_responsavel, observacoes } = req.body;
    try {
      const updatePayload = {};
      if (id_produto !== undefined) updatePayload.id_produto = id_produto;
      if (id_lote !== undefined) updatePayload.id_lote = id_lote;
      if (tipo_movimentacao !== undefined) {
        if (!["Entrada", "Saida_Venda", "Saida_Uso", "Ajuste_Positivo", "Ajuste_Negativo"].includes(tipo_movimentacao)) {
          return res.status(400).json({ message: "Tipo de movimentação inválido." });
        }
        updatePayload.tipo_movimentacao = tipo_movimentacao;
      }
      if (quantidade !== undefined) updatePayload.quantidade = quantidade;
      if (id_usuario_responsavel !== undefined) updatePayload.id_usuario_responsavel = id_usuario_responsavel;
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      // AVISO: A lógica para reajustar o estoque de produtos/lotes ao atualizar uma movimentação é complexa
      // e NÃO está implementada aqui. Em muitos sistemas, este endpoint é desabilitado ou
      // requer lógica de reconciliação de estoque muito cuidadosa.
      // É mais comum criar uma nova movimentação de "ajuste" do que alterar uma movimentação histórica.

      const { data, error } = await supabase.from("movimentacao_estoque").update(updatePayload).eq("id_movimentacao", id).select();

      if (error) {
        console.error("Erro ao atualizar movimentação de estoque:", error);
        return res.status(500).json({ message: "Erro ao atualizar movimentação de estoque.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Movimentação de estoque não encontrada para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em movimentacaoEstoqueController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/movimentacao-estoque/:id
   * @desc Deleta uma movimentação de estoque.
   * @param {string} req.params.id - ID da movimentação a ser deletada.
   * @access Restrito (apenas para Gestores com extrema cautela)
   * @note A deleção de movimentações de estoque é altamente desaconselhada, pois compromete o histórico e a auditoria.
   * Normalmente, os ajustes são feitos com novas movimentações. Se deletado, a reversão do estoque NÃO está implementada aqui.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // AVISO: A remoção de uma movimentação de estoque do histórico é perigosa.
      // Para manter a integridade, você precisaria reverter o efeito dessa movimentação
      // no estoque_atual do produto e na quantidade_disponivel do lote.
      // Essa lógica de reversão NÃO está implementada aqui.
      // Considere fortemente desabilitar a deleção de movimentações históricas.

      const { error } = await supabase.from("movimentacao_estoque").delete().eq("id_movimentacao", id);

      if (error) {
        console.error("Erro ao deletar movimentação de estoque:", error);
        return res.status(500).json({ message: "Erro ao deletar movimentação de estoque.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em movimentacaoEstoqueController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

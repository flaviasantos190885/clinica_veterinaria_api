import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const faturasController = {
  /**
   * @route GET /api/faturas
   * @desc Busca todas as faturas. Pode ser filtrado por id_cliente, status_fatura, e intervalo de datas.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getAll: async (req, res) => {
    try {
      const { id_cliente, status_fatura, data_emissao_apos, data_vencimento_antes } = req.query;
      let query = supabase.from("faturas").select("*");

      if (id_cliente) {
        query = query.eq("id_cliente", id_cliente);
      }
      if (status_fatura) {
        query = query.eq("status_fatura", status_fatura);
      }
      if (data_emissao_apos) {
        query = query.gte("data_emissao", data_emissao_apos);
      }
      if (data_vencimento_antes) {
        query = query.lte("data_vencimento", data_vencimento_antes);
      }

      // Ordena por data de emissão padrão
      query = query.order("data_emissao", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar faturas:", error);
        return res.status(500).json({ message: "Erro ao buscar faturas.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em faturasController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/faturas/:id
   * @desc Busca uma fatura pelo ID.
   * @param {string} req.params.id - ID da fatura.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("faturas").select("*").eq("id_fatura", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar fatura por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar fatura.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Fatura não encontrada." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em faturasController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/faturas
   * @desc Cria uma nova fatura.
   * @param {object} req.body - Dados da fatura a ser criada.
   * @access Restrito (Recepcionistas, Gestores)
   */
  create: async (req, res) => {
    const { id_atendimento, id_cliente, data_emissao, data_vencimento, valor_total, status_fatura, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_cliente || valor_total === undefined) {
        return res.status(400).json({ message: "ID do cliente e valor total são obrigatórios." });
      }
      if (status_fatura && !["Pendente", "Paga", "Parcialmente_Paga", "Cancelada"].includes(status_fatura)) {
        return res.status(400).json({ message: "Status de fatura inválido." });
      }

      const { data, error } = await supabase
        .from("faturas")
        .insert([
          {
            id_atendimento: id_atendimento || null,
            id_cliente,
            data_emissao: data_emissao || new Date().toISOString(),
            data_vencimento,
            valor_total,
            status_fatura: status_fatura || "Pendente",
            observacoes,
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao criar fatura:", error);
        return res.status(500).json({ message: "Erro ao criar fatura.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em faturasController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/faturas/:id
   * @desc Atualiza uma fatura existente.
   * @param {string} req.params.id - ID da fatura a ser atualizada.
   * @param {object} req.body - Dados da fatura a serem atualizados.
   * @access Restrito (Recepcionistas, Gestores)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_atendimento, id_cliente, data_emissao, data_vencimento, valor_total, status_fatura, observacoes } = req.body;
    try {
      const updatePayload = {};
      if (id_atendimento !== undefined) updatePayload.id_atendimento = id_atendimento;
      if (id_cliente !== undefined) updatePayload.id_cliente = id_cliente;
      if (data_emissao !== undefined) updatePayload.data_emissao = data_emissao;
      if (data_vencimento !== undefined) updatePayload.data_vencimento = data_vencimento;
      if (valor_total !== undefined) updatePayload.valor_total = valor_total;
      if (status_fatura !== undefined) {
        if (!["Pendente", "Paga", "Parcialmente_Paga", "Cancelada"].includes(status_fatura)) {
          return res.status(400).json({ message: "Status de fatura inválido." });
        }
        updatePayload.status_fatura = status_fatura;
      }
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      const { data, error } = await supabase.from("faturas").update(updatePayload).eq("id_fatura", id).select();

      if (error) {
        console.error("Erro ao atualizar fatura:", error);
        return res.status(500).json({ message: "Erro ao atualizar fatura.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Fatura não encontrada para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em faturasController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/faturas/:id
   * @desc Deleta (cancela) uma fatura.
   * @param {string} req.params.id - ID da fatura a ser cancelada.
   * @access Restrito (apenas para Gestores com cautela)
   * @note Considerar sempre um soft delete (mudar status para 'Cancelada') para manter o histórico financeiro.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Soft delete: mudar o status para 'Cancelada'
      const { data, error } = await supabase.from("faturas").update({ status_fatura: "Cancelada" }).eq("id_fatura", id).select();

      if (error) {
        console.error("Erro ao cancelar fatura:", error);
        return res.status(500).json({ message: "Erro ao cancelar fatura.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Fatura não encontrada para cancelamento." });
      }

      return res.status(200).json({ message: "Fatura cancelada com sucesso.", fatura: data[0] });

      /*
            // Opção 2: Hard delete (deleta o registro permanentemente)
            // CUIDADO: Isso pode violar restrições de chave estrangeira (itens_fatura, pagamentos, atendimento_fatura)
            const { error: hardDeleteError } = await supabase
                .from('faturas')
                .delete()
                .eq('id_fatura', id);

            if (hardDeleteError) {
                console.error("Erro ao deletar fatura:", hardDeleteError);
                return res.status(500).json({ message: "Erro ao deletar fatura. Verifique dependências.", error: hardDeleteError.message });
            }

            return res.status(204).send(); // No Content
            */
    } catch (err) {
      console.error("Exceção em faturasController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/faturas/:id/itens
   * @desc Busca todos os itens de uma fatura específica.
   * @param {string} req.params.id - ID da fatura.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getItensFatura: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("itens_fatura").select("*").eq("id_fatura", id);

      if (error) {
        console.error("Erro ao buscar itens da fatura:", error);
        return res.status(500).json({ message: "Erro ao buscar itens da fatura.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em faturasController.getItensFatura:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/faturas/:id/pagamentos
   * @desc Busca todos os pagamentos de uma fatura específica.
   * @param {string} req.params.id - ID da fatura.
   * @access Restrito (Gestores, Recepcionistas)
   */
  getPagamentos: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("pagamentos").select("*").eq("id_fatura", id);

      if (error) {
        console.error("Erro ao buscar pagamentos da fatura:", error);
        return res.status(500).json({ message: "Erro ao buscar pagamentos da fatura.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em faturasController.getPagamentos:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/faturas/:id/atendimento
   * @desc Busca o atendimento (prontuário) associado a esta fatura.
   * @param {string} req.params.id - ID da fatura.
   * @access Restrito (Gestores, Recepcionistas, Veterinários com restrições)
   */
  getAtendimento: async (req, res) => {
    const { id } = req.params;
    try {
      // Busca a entrada na tabela atendimento_fatura
      const { data: atendimentoFaturaData, error: atendimentoFaturaError } = await supabase.from("atendimento_fatura").select("id_prontuario").eq("id_fatura", id).single();

      if (atendimentoFaturaError && atendimentoFaturaError.code !== "PGRST116") {
        console.error("Erro ao buscar relação fatura-atendimento:", atendimentoFaturaError.message);
        return res.status(500).json({ message: "Erro ao buscar relação de atendimento.", error: atendimentoFaturaError.message });
      }

      if (!atendimentoFaturaData) {
        return res.status(404).json({ message: "Nenhum atendimento associado a esta fatura." });
      }

      // Com o id_prontuario, busca os detalhes do prontuário
      const { data: prontuarioData, error: prontuarioError } = await supabase.from("prontuarios").select("*").eq("id_prontuario", atendimentoFaturaData.id_prontuario).single();

      if (prontuarioError) {
        console.error("Erro ao buscar prontuário por ID:", prontuarioError.message);
        return res.status(500).json({ message: "Erro ao buscar prontuário.", error: prontuarioError.message });
      }

      return res.status(200).json(prontuarioData);
    } catch (err) {
      console.error("Exceção em faturasController.getAtendimento:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

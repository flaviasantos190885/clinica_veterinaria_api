import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const animaisController = {
  /**
   * @route GET /api/animais
   * @desc Busca todos os animais.
   * @access Public
   */
  getAll: async (req, res) => {
    try {
      // Permite filtrar por id_cliente, se passado na query string
      const { id_cliente } = req.query;
      let query = supabase.from("animais").select("*");

      if (id_cliente) {
        query = query.eq("id_cliente", id_cliente);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar animais:", error);
        return res.status(500).json({ message: "Erro ao buscar animais.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em animaisController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/animais/:id
   * @desc Busca um animal pelo ID.
   * @param {string} req.params.id - ID do animal.
   * @access Public
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("animais").select("*").eq("id_animal", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar animal por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar animal.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Animal não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em animaisController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/animais
   * @desc Cria um novo animal.
   * @param {object} req.body - Dados do animal a ser criado.
   * @access Public (ou restrito por autenticação/autorização)
   */
  create: async (req, res) => {
    const { id_cliente, nome, especie, raca, data_nascimento, sexo, peso, observacoes } = req.body;
    try {
      // Validação básica para id_cliente e nome
      if (!id_cliente || !nome || !especie) {
        return res.status(400).json({ message: "ID do cliente, nome e espécie são obrigatórios." });
      }

      const { data, error } = await supabase.from("animais").insert([{ id_cliente, nome, especie, raca, data_nascimento, sexo, peso, observacoes }]).select(); // Retorna os dados do animal criado

      if (error) {
        console.error("Erro ao criar animal:", error);
        return res.status(500).json({ message: "Erro ao criar animal.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em animaisController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/animais/:id
   * @desc Atualiza um animal existente.
   * @param {string} req.params.id - ID do animal a ser atualizado.
   * @param {object} req.body - Dados do animal a serem atualizados.
   * @access Public (ou restrito por autenticação/autorização)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_cliente, nome, especie, raca, data_nascimento, sexo, peso, observacoes } = req.body;
    try {
      const { data, error } = await supabase
        .from("animais")
        .update({ id_cliente, nome, especie, raca, data_nascimento, sexo, peso, observacoes, data_atualizacao: new Date().toISOString() })
        .eq("id_animal", id)
        .select();

      if (error) {
        console.error("Erro ao atualizar animal:", error);
        return res.status(500).json({ message: "Erro ao atualizar animal.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Animal não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em animaisController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/animais/:id
   * @desc Deleta um animal.
   * @param {string} req.params.id - ID do animal a ser deletado.
   * @access Public (ou restrito por autenticação/autorização)
   * @note Considere que a deleção de um animal pode requerer a deleção em cascata de prontuários, vacinas, etc.,
   * ou a implementação de um soft delete na tabela 'animais' se você quiser manter o histórico.
   * Atualmente, o esquema não tem um campo 'ativo' para 'animais'. Se necessário, adicione-o.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Antes de deletar o animal, você pode querer verificar se existem prontuários associados
      // e decidir se deve impedir a deleção ou deletar em cascata.
      // Para simplicidade, aqui estamos fazendo um hard delete.
      const { error } = await supabase.from("animais").delete().eq("id_animal", id);

      if (error) {
        console.error("Erro ao deletar animal:", error);
        // Se houver erro de chave estrangeira, a mensagem de erro do Supabase pode ser útil
        return res.status(500).json({ message: "Erro ao deletar animal. Verifique dependências (prontuários, etc.).", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em animaisController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/animais/:id/prontuarios
   * @desc Busca todos os prontuários de um animal específico.
   * @param {string} req.params.id - ID do animal.
   * @access Public
   */
  getProntuarios: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("prontuarios").select("*").eq("id_animal", id);

      if (error) {
        console.error("Erro ao buscar prontuários do animal:", error);
        return res.status(500).json({ message: "Erro ao buscar prontuários do animal.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Nenhum prontuário encontrado para este animal." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em animaisController.getProntuarios:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

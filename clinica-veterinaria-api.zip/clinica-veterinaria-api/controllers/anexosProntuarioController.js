import { supabase } from "../database/database.js"; // Importa o cliente Supabase
// Para uploads de arquivos reais, você precisaria de uma biblioteca como 'multer' e configurar o armazenamento.
// Por exemplo, usando o Storage do Supabase:
// import { v4 as uuidv4 } from 'uuid'; // Para gerar nomes de arquivo únicos
// import path from 'path'; // Para lidar com caminhos de arquivo

export const anexosProntuarioController = {
  /**
   * @route GET /api/anexos-prontuario
   * @desc Busca todos os anexos de prontuário. Pode ser filtrado por id_prontuario ou tipo_arquivo.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getAll: async (req, res) => {
    try {
      const { id_prontuario, tipo_arquivo } = req.query;
      let query = supabase.from("anexos_prontuario").select("*");

      if (id_prontuario) {
        query = query.eq("id_prontuario", id_prontuario);
      }
      if (tipo_arquivo) {
        query = query.eq("tipo_arquivo", tipo_arquivo);
      }

      // Opcional: Ordenar por data de upload
      query = query.order("data_upload", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar anexos de prontuário:", error);
        return res.status(500).json({ message: "Erro ao buscar anexos de prontuário.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em anexosProntuarioController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/anexos-prontuario/:id
   * @desc Busca um anexo de prontuário pelo ID.
   * @param {string} req.params.id - ID do anexo.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("anexos_prontuario").select("*").eq("id_anexo", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar anexo de prontuário por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar anexo de prontuário.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Anexo de prontuário não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em anexosProntuarioController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/anexos-prontuario
   * @desc Cria um novo registro de anexo de prontuário.
   * @param {object} req.body - Dados do anexo a ser criado (id_prontuario, nome_arquivo, caminho_arquivo, tipo_arquivo).
   * @access Restrito (apenas para Veterinários)
   * @note Para upload de arquivos reais, você integraria aqui com um serviço de armazenamento (ex: Supabase Storage).
   */
  create: async (req, res) => {
    const { id_prontuario, nome_arquivo, caminho_arquivo, tipo_arquivo } = req.body;
    try {
      // Validação básica
      if (!id_prontuario || !nome_arquivo || !caminho_arquivo) {
        return res.status(400).json({ message: "ID do prontuário, nome do arquivo e caminho do arquivo são obrigatórios." });
      }

      // Exemplo de como seria um upload (conceitual, requer mais setup real de storage)
      // const file = req.file; // Se estiver usando 'multer'
      // const filePath = `prontuarios/${id_prontuario}/${uuidv4()}-${file.originalname}`;
      // const { data: uploadData, error: uploadError } = await supabase.storage
      //     .from('prontuarios') // Nome do seu bucket no Supabase Storage
      //     .upload(filePath, file.buffer, { contentType: file.mimetype });
      // if (uploadError) throw uploadError;
      // const publicUrl = supabase.storage.from('prontuarios').getPublicUrl(filePath).data.publicUrl;

      const { data, error } = await supabase
        .from("anexos_prontuario")
        .insert([
          {
            id_prontuario,
            nome_arquivo,
            caminho_arquivo, // Em um cenário real, seria a URL pública do arquivo
            tipo_arquivo: tipo_arquivo || "application/octet-stream", // Tipo MIME padrão
            data_upload: new Date().toISOString(),
          },
        ])
        .select();

      if (error) {
        console.error("Erro ao registrar anexo de prontuário:", error);
        return res.status(500).json({ message: "Erro ao registrar anexo de prontuário.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em anexosProntuarioController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/anexos-prontuario/:id
   * @desc Atualiza um registro de anexo de prontuário existente.
   * @param {string} req.params.id - ID do anexo a ser atualizado.
   * @param {object} req.body - Dados do anexo a serem atualizados (nome_arquivo, caminho_arquivo, tipo_arquivo).
   * @access Restrito (apenas para Veterinários)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { nome_arquivo, caminho_arquivo, tipo_arquivo } = req.body;
    try {
      const updatePayload = {};
      if (nome_arquivo !== undefined) updatePayload.nome_arquivo = nome_arquivo;
      if (caminho_arquivo !== undefined) updatePayload.caminho_arquivo = caminho_arquivo;
      if (tipo_arquivo !== undefined) updatePayload.tipo_arquivo = tipo_arquivo;

      const { data, error } = await supabase.from("anexos_prontuario").update(updatePayload).eq("id_anexo", id).select();

      if (error) {
        console.error("Erro ao atualizar anexo de prontuário:", error);
        return res.status(500).json({ message: "Erro ao atualizar anexo de prontuário.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Anexo de prontuário não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em anexosProntuarioController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/anexos-prontuario/:id
   * @desc Deleta um registro de anexo de prontuário.
   * @param {string} req.params.id - ID do anexo a ser deletado.
   * @access Restrito (apenas para Veterinários/Gestores com cautela)
   * @note Se estiver usando armazenamento de arquivos, também precisaria deletar o arquivo do storage.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Primeiro, obtenha o caminho do arquivo para deletá-lo do storage, se aplicável
      // const { data: anexoData, error: anexoError } = await supabase.from('anexos_prontuario').select('caminho_arquivo').eq('id_anexo', id).single();
      // if (anexoError && anexoError.code !== 'PGRST116') throw anexoError;
      // if (anexoData && anexoData.caminho_arquivo) {
      //     const { error: deleteStorageError } = await supabase.storage.from('prontuarios').remove([anexoData.caminho_arquivo]);
      //     if (deleteStorageError) console.warn('Erro ao deletar arquivo do storage:', deleteStorageError.message);
      // }

      const { error } = await supabase.from("anexos_prontuario").delete().eq("id_anexo", id);

      if (error) {
        console.error("Erro ao deletar anexo de prontuário:", error);
        return res.status(500).json({ message: "Erro ao deletar anexo de prontuário.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em anexosProntuarioController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

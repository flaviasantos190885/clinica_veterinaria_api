import { supabase } from "../database/database.js"; // Importa o cliente Supabase

export const prontuariosController = {
  /**
   * @route GET /api/prontuarios
   * @desc Busca todos os prontuários. Pode ser filtrado por id_animal, id_veterinario, ou tipo_atendimento.
   * @access Restrito (Veterinários, Gestores)
   */
  getAll: async (req, res) => {
    try {
      const { id_animal, id_veterinario, tipo_atendimento } = req.query;
      let query = supabase.from("prontuarios").select("*");

      if (id_animal) {
        query = query.eq("id_animal", id_animal);
      }
      if (id_veterinario) {
        query = query.eq("id_veterinario", id_veterinario);
      }
      if (tipo_atendimento) {
        query = query.eq("tipo_atendimento", tipo_atendimento);
      }

      // Opcional: Adicionar ordenação padrão, por exemplo, por data_atendimento descendente
      query = query.order("data_atendimento", { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error("Erro ao buscar prontuários:", error);
        return res.status(500).json({ message: "Erro ao buscar prontuários.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prontuariosController.getAll:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prontuarios/:id
   * @desc Busca um prontuário pelo ID.
   * @param {string} req.params.id - ID do prontuário.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getById: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("prontuarios").select("*").eq("id_prontuario", id).single();

      if (error && error.code !== "PGRST116") {
        // PGRST116 é "No rows found"
        console.error("Erro ao buscar prontuário por ID:", error);
        return res.status(500).json({ message: "Erro ao buscar prontuário.", error: error.message });
      }

      if (!data) {
        return res.status(404).json({ message: "Prontuário não encontrado." });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prontuariosController.getById:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route POST /api/prontuarios
   * @desc Cria um novo prontuário.
   * @param {object} req.body - Dados do prontuário a ser criado.
   * @access Restrito (apenas para Veterinários)
   */
  create: async (req, res) => {
    const { id_animal, data_atendimento, id_veterinario, tipo_atendimento, anamnese, diagnostico, procedimentos_realizados, observacoes } = req.body;
    try {
      // Validação básica
      if (!id_animal || !id_veterinario || !tipo_atendimento || !anamnese || !diagnostico) {
        return res.status(400).json({ message: "ID do animal, ID do veterinário, tipo de atendimento, anamnese e diagnóstico são obrigatórios." });
      }

      const { data, error } = await supabase
        .from("prontuarios")
        .insert([{ id_animal, data_atendimento: data_atendimento || new Date().toISOString(), id_veterinario, tipo_atendimento, anamnese, diagnostico, procedimentos_realizados, observacoes }])
        .select();

      if (error) {
        console.error("Erro ao criar prontuário:", error);
        return res.status(500).json({ message: "Erro ao criar prontuário.", error: error.message });
      }

      return res.status(201).json(data[0]);
    } catch (err) {
      console.error("Exceção em prontuariosController.create:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route PUT /api/prontuarios/:id
   * @desc Atualiza um prontuário existente.
   * @param {string} req.params.id - ID do prontuário a ser atualizado.
   * @param {object} req.body - Dados do prontuário a serem atualizados.
   * @access Restrito (apenas para Veterinários ou Gestores)
   */
  update: async (req, res) => {
    const { id } = req.params;
    const { id_animal, data_atendimento, id_veterinario, tipo_atendimento, anamnese, diagnostico, procedimentos_realizados, observacoes } = req.body;
    try {
      const updatePayload = { data_atualizacao: new Date().toISOString() }; // A tabela prontuarios não tem data_atualizacao no seu schema atual, mas é uma boa prática adicionar.
      if (id_animal !== undefined) updatePayload.id_animal = id_animal;
      if (data_atendimento !== undefined) updatePayload.data_atendimento = data_atendimento;
      if (id_veterinario !== undefined) updatePayload.id_veterinario = id_veterinario;
      if (tipo_atendimento !== undefined) updatePayload.tipo_atendimento = tipo_atendimento;
      if (anamnese !== undefined) updatePayload.anamnese = anamnese;
      if (diagnostico !== undefined) updatePayload.diagnostico = diagnostico;
      if (procedimentos_realizados !== undefined) updatePayload.procedimentos_realizados = procedimentos_realizados;
      if (observacoes !== undefined) updatePayload.observacoes = observacoes;

      const { data, error } = await supabase.from("prontuarios").update(updatePayload).eq("id_prontuario", id).select();

      if (error) {
        console.error("Erro ao atualizar prontuário:", error);
        return res.status(500).json({ message: "Erro ao atualizar prontuário.", error: error.message });
      }

      if (!data || data.length === 0) {
        return res.status(404).json({ message: "Prontuário não encontrado para atualização." });
      }

      return res.status(200).json(data[0]);
    } catch (err) {
      console.error("Exceção em prontuariosController.update:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route DELETE /api/prontuarios/:id
   * @desc Deleta um prontuário.
   * @param {string} req.params.id - ID do prontuário a ser deletado.
   * @access Restrito (apenas para Gestores ou com muita cautela para Veterinários)
   * @note A deleção de prontuários deve ser tratada com EXTREMA cautela devido à sensibilidade dos dados.
   * Pode ser preferível implementar um soft delete (adicionando uma coluna 'ativo' ou similar).
   * Atualmente, o esquema não tem um campo 'ativo' para 'prontuarios'. Se necessário, adicione-o.
   * Uma deleção em cascata pode ser necessária para prescrições, vacinas, e anexos.
   */
  delete: async (req, res) => {
    const { id } = req.params;
    try {
      // Para garantir a integridade, é recomendável deletar registros relacionados
      // (prescrições, vacinas, anexos) ANTES de deletar o prontuário.
      // O Supabase suporta deletes em cascata se configurado nas Foreign Keys no banco de dados.

      // Exemplo de deleção de dependências (se não houver cascata configurada no DB)
      await supabase.from("prescricoes").delete().eq("id_prontuario", id);
      await supabase.from("vacinas").delete().eq("id_prontuario", id);
      await supabase.from("anexos_prontuario").delete().eq("id_prontuario", id);
      await supabase.from("atendimento_fatura").delete().eq("id_prontuario", id);

      const { error } = await supabase.from("prontuarios").delete().eq("id_prontuario", id);

      if (error) {
        console.error("Erro ao deletar prontuário:", error);
        return res.status(500).json({ message: "Erro ao deletar prontuário.", error: error.message });
      }

      return res.status(204).send(); // No Content
    } catch (err) {
      console.error("Exceção em prontuariosController.delete:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prontuarios/:id/prescricoes
   * @desc Busca todas as prescrições de um prontuário específico.
   * @param {string} req.params.id - ID do prontuário.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getPrescricoes: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("prescricoes").select("*").eq("id_prontuario", id);

      if (error) {
        console.error("Erro ao buscar prescrições do prontuário:", error);
        return res.status(500).json({ message: "Erro ao buscar prescrições do prontuário.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prontuariosController.getPrescricoes:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prontuarios/:id/vacinas
   * @desc Busca todas as vacinas registradas em um prontuário específico.
   * @param {string} req.params.id - ID do prontuário.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getVacinas: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("vacinas").select("*").eq("id_prontuario", id);

      if (error) {
        console.error("Erro ao buscar vacinas do prontuário:", error);
        return res.status(500).json({ message: "Erro ao buscar vacinas do prontuário.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prontuariosController.getVacinas:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prontuarios/:id/anexos
   * @desc Busca todos os anexos de um prontuário específico.
   * @param {string} req.params.id - ID do prontuário.
   * @access Restrito (Veterinários, Gestores, Recepcionistas com restrições)
   */
  getAnexos: async (req, res) => {
    const { id } = req.params;
    try {
      const { data, error } = await supabase.from("anexos_prontuario").select("*").eq("id_prontuario", id);

      if (error) {
        console.error("Erro ao buscar anexos do prontuário:", error);
        return res.status(500).json({ message: "Erro ao buscar anexos do prontuário.", error: error.message });
      }

      return res.status(200).json(data);
    } catch (err) {
      console.error("Exceção em prontuariosController.getAnexos:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },

  /**
   * @route GET /api/prontuarios/:id/fatura
   * @desc Busca a fatura associada a um prontuário (atendimento).
   * @param {string} req.params.id - ID do prontuário.
   * @access Restrito (Veterinários, Gestores, Recepcionistas)
   */
  getFatura: async (req, res) => {
    const { id } = req.params;
    try {
      // Busca a entrada na tabela atendimento_fatura
      const { data: atendimentoFaturaData, error: atendimentoFaturaError } = await supabase.from("atendimento_fatura").select("id_fatura").eq("id_prontuario", id).single();

      if (atendimentoFaturaError && atendimentoFaturaError.code !== "PGRST116") {
        console.error("Erro ao buscar relação prontuário-fatura:", atendimentoFaturaError.message);
        return res.status(500).json({ message: "Erro ao buscar relação de fatura.", error: atendimentoFaturaError.message });
      }

      if (!atendimentoFaturaData) {
        return res.status(404).json({ message: "Nenhuma fatura associada a este prontuário." });
      }

      // Com o id_fatura, busca os detalhes da fatura
      const { data: faturaData, error: faturaError } = await supabase.from("faturas").select("*").eq("id_fatura", atendimentoFaturaData.id_fatura).single();

      if (faturaError) {
        console.error("Erro ao buscar fatura por ID:", faturaError.message);
        return res.status(500).json({ message: "Erro ao buscar fatura.", error: faturaError.message });
      }

      return res.status(200).json(faturaData);
    } catch (err) {
      console.error("Exceção em prontuariosController.getFatura:", err);
      return res.status(500).json({ message: "Erro interno do servidor.", error: err.message });
    }
  },
};

import express from "express";
import { vacinasController } from "../controllers/vacinasController.js";

const router = express.Router();

// Rotas para a gestão de vacinas
router.get("/", vacinasController.getAll); // GET /api/vacinas
router.get("/:id", vacinasController.getById); // GET /api/vacinas/:id
router.post("/", vacinasController.create); // POST /api/vacinas
router.put("/:id", vacinasController.update); // PUT /api/vacinas/:id
router.delete("/:id", vacinasController.delete); // DELETE /api/vacinas/:id

export default router;

import express from "express";
import { lotesProdutoController } from "../controllers/lotesProdutoController.js";

const router = express.Router();

// Rotas para a gestão de lotes de produto
router.get("/", lotesProdutoController.getAll); // GET /api/lotes-produto
router.get("/:id", lotesProdutoController.getById); // GET /api/lotes-produto/:id
router.post("/", lotesProdutoController.create); // POST /api/lotes-produto
router.put("/:id", lotesProdutoController.update); // PUT /api/lotes-produto/:id
router.delete("/:id", lotesProdutoController.delete); // DELETE /api/lotes-produto/:id

export default router;

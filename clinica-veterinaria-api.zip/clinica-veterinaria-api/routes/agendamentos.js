import express from "express";
import { agendamentosController } from "../controllers/agendamentosController.js";

const router = express.Router();

// Rotas para a gestão de agendamentos
router.get("/", agendamentosController.getAll); // GET /api/agendamentos
router.get("/:id", agendamentosController.getById); // GET /api/agendamentos/:id
router.post("/", agendamentosController.create); // POST /api/agendamentos
router.put("/:id", agendamentosController.update); // PUT /api/agendamentos/:id
router.delete("/:id", agendamentosController.delete); // DELETE /api/agendamentos/:id (soft delete/cancelamento)

export default router;

import express from "express";
import { movimentacaoEstoqueController } from "../controllers/movimentacaoEstoqueController.js";

const router = express.Router();

// Rotas para a gestão de movimentações de estoque
router.get("/", movimentacaoEstoqueController.getAll); // GET /api/movimentacao-estoque
router.get("/:id", movimentacaoEstoqueController.getById); // GET /api/movimentacao-estoque/:id
router.post("/", movimentacaoEstoqueController.create); // POST /api/movimentacao-estoque
router.put("/:id", movimentacaoEstoqueController.update); // PUT /api/movimentacao-estoque/:id
router.delete("/:id", movimentacaoEstoqueController.delete); // DELETE /api/movimentacao-estoque/:id

export default router;

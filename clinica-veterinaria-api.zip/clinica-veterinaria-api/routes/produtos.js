import express from "express";
import { produtosController } from "../controllers/produtosController.js";

const router = express.Router();

// Rotas para a gestão de produtos
router.get("/", produtosController.getAll); // GET /api/produtos
router.get("/:id", produtosController.getById); // GET /api/produtos/:id
router.post("/", produtosController.create); // POST /api/produtos
router.put("/:id", produtosController.update); // PUT /api/produtos/:id
router.delete("/:id", produtosController.delete); // DELETE /api/produtos/:id (soft delete)

// Rotas para buscar dados relacionados a um produto específico
router.get("/:id/lotes", produtosController.getLotes); // GET /api/produtos/:id/lotes
router.get("/:id/movimentacoes", produtosController.getMovimentacoes); // GET /api/produtos/:id/movimentacoes

export default router;

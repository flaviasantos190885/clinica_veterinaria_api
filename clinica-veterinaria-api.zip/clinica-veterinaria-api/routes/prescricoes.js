import express from "express";
import { prescricoesController } from "../controllers/prescricoesController.js";

const router = express.Router();

// Rotas para a gestão de prescrições
router.get("/", prescricoesController.getAll); // GET /api/prescricoes
router.get("/:id", prescricoesController.getById); // GET /api/prescricoes/:id
router.post("/", prescricoesController.create); // POST /api/prescricoes
router.put("/:id", prescricoesController.update); // PUT /api/prescricoes/:id
router.delete("/:id", prescricoesController.delete); // DELETE /api/prescricoes/:id

export default router;

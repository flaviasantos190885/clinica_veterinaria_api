import express from "express";
import { itensFaturaController } from "../controllers/itensFaturaController.js";

const router = express.Router();

// Rotas para a gestão de itens de fatura
router.get("/", itensFaturaController.getAll); // GET /api/itens-fatura
router.get("/:id", itensFaturaController.getById); // GET /api/itens-fatura/:id
router.post("/", itensFaturaController.create); // POST /api/itens-fatura
router.put("/:id", itensFaturaController.update); // PUT /api/itens-fatura/:id
router.delete("/:id", itensFaturaController.delete); // DELETE /api/itens-fatura/:id

export default router;

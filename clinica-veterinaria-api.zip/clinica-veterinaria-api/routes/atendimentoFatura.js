import express from "express";
import { atendimentoFaturaController } from "../controllers/atendimentoFaturaController.js";

const router = express.Router();

// Rotas para a gestão de ligações atendimento-fatura
router.get("/", atendimentoFaturaController.getAll); // GET /api/atendimento-fatura
router.get("/:id", atendimentoFaturaController.getById); // GET /api/atendimento-fatura/:id
router.post("/", atendimentoFaturaController.create); // POST /api/atendimento-fatura
router.put("/:id", atendimentoFaturaController.update); // PUT /api/atendimento-fatura/:id
router.delete("/:id", atendimentoFaturaController.delete); // DELETE /api/atendimento-fatura/:id

export default router;

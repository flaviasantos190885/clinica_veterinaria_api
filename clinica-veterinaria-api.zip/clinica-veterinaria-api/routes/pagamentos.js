import express from "express";
import { pagamentosController } from "../controllers/pagamentosController.js";

const router = express.Router();

// Rotas para a gestão de pagamentos
router.get("/", pagamentosController.getAll); // GET /api/pagamentos
router.get("/:id", pagamentosController.getById); // GET /api/pagamentos/:id
router.post("/", pagamentosController.create); // POST /api/pagamentos
router.put("/:id", pagamentosController.update); // PUT /api/pagamentos/:id
router.delete("/:id", pagamentosController.delete); // DELETE /api/pagamentos/:id

export default router;

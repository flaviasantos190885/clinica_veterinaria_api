import express from "express";
import { anexosProntuarioController } from "../controllers/anexosProntuarioController.js";

const router = express.Router();

// Rotas para a gestão de anexos de prontuário
router.get("/", anexosProntuarioController.getAll); // GET /api/anexos-prontuario
router.get("/:id", anexosProntuarioController.getById); // GET /api/anexos-prontuario/:id
router.post("/", anexosProntuarioController.create); // POST /api/anexos-prontuario
router.put("/:id", anexosProntuarioController.update); // PUT /api/anexos-prontuario/:id
router.delete("/:id", anexosProntuarioController.delete); // DELETE /api/anexos-prontuario/:id

export default router;

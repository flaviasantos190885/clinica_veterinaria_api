import express from "express";
import { clientesController } from "../controllers/clientesController.js";

const router = express.Router();

// Rotas para a gestão de clientes
router.get("/", clientesController.getAll); // GET /api/clientes
router.get("/:id", clientesController.getById); // GET /api/clientes/:id
router.post("/", clientesController.create); // POST /api/clientes
router.put("/:id", clientesController.update); // PUT /api/clientes/:id
router.delete("/:id", clientesController.delete); // DELETE /api/clientes/:id

// Rota para buscar os animais de um cliente específico
router.get("/:id/animais", clientesController.getAnimais); // GET /api/clientes/:id/animais

export default router;

import express from "express";
import { prontuariosController } from "../controllers/prontuariosController.js";

const router = express.Router();

// Rotas para a gestão de prontuários
router.get("/", prontuariosController.getAll); // GET /api/prontuarios
router.get("/:id", prontuariosController.getById); // GET /api/prontuarios/:id
router.post("/", prontuariosController.create); // POST /api/prontuarios
router.put("/:id", prontuariosController.update); // PUT /api/prontuarios/:id
router.delete("/:id", prontuariosController.delete); // DELETE /api/prontuarios/:id

// Rotas para buscar dados relacionados a um prontuário específico
router.get("/:id/prescricoes", prontuariosController.getPrescricoes); // GET /api/prontuarios/:id/prescricoes
router.get("/:id/vacinas", prontuariosController.getVacinas); // GET /api/prontuarios/:id/vacinas
router.get("/:id/anexos", prontuariosController.getAnexos); // GET /api/prontuarios/:id/anexos
router.get("/:id/fatura", prontuariosController.getFatura); // GET /api/prontuarios/:id/fatura

export default router;

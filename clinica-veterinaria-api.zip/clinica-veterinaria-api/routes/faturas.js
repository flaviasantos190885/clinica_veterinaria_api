import express from "express";
import { faturasController } from "../controllers/faturasController.js";

const router = express.Router();

// Rotas para a gestão de faturas
router.get("/", faturasController.getAll); // GET /api/faturas
router.get("/:id", faturasController.getById); // GET /api/faturas/:id
router.post("/", faturasController.create); // POST /api/faturas
router.put("/:id", faturasController.update); // PUT /api/faturas/:id
router.delete("/:id", faturasController.delete); // DELETE /api/faturas/:id (soft delete/cancelamento)

// Rotas para buscar dados relacionados a uma fatura específica
router.get("/:id/itens", faturasController.getItensFatura); // GET /api/faturas/:id/itens
router.get("/:id/pagamentos", faturasController.getPagamentos); // GET /api/faturas/:id/pagamentos
router.get("/:id/atendimento", faturasController.getAtendimento); // GET /api/faturas/:id/atendimento

export default router;

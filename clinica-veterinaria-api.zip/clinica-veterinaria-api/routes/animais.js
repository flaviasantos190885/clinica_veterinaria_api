import express from "express";
import { animaisController } from "../controllers/animaisController.js";

const router = express.Router();

// Rotas para a gestão de animais
router.get("/", animaisController.getAll); // GET /api/animais (pode receber ?id_cliente=UUID)
router.get("/:id", animaisController.getById); // GET /api/animais/:id
router.post("/", animaisController.create); // POST /api/animais
router.put("/:id", animaisController.update); // PUT /api/animais/:id
router.delete("/:id", animaisController.delete); // DELETE /api/animais/:id

// Rota para buscar os prontuários de um animal específico
router.get("/:id/prontuarios", animaisController.getProntuarios); // GET /api/animais/:id/prontuarios

export default router;
